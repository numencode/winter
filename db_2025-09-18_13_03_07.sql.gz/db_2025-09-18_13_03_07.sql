/*M!999999\- enable the sandbox mode */ 

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;
DROP TABLE IF EXISTS `backend_access_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_access_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `backend_access_log` WRITE;
/*!40000 ALTER TABLE `backend_access_log` DISABLE KEYS */;
REPLACE INTO `backend_access_log` VALUES
(1,1,'89.143.131.136','2025-02-13 11:01:59','2025-02-13 11:01:59'),
(2,1,'89.143.131.136','2025-02-13 11:07:00','2025-02-13 11:07:00'),
(3,1,'89.143.131.136','2025-02-13 11:07:12','2025-02-13 11:07:12'),
(4,1,'89.143.131.136','2025-02-13 11:14:52','2025-02-13 11:14:52'),
(5,1,'89.143.131.136','2025-02-13 12:13:15','2025-02-13 12:13:15'),
(6,1,'84.255.203.125','2025-02-14 08:50:51','2025-02-14 08:50:51'),
(7,1,'84.255.203.125','2025-02-18 13:19:58','2025-02-18 13:19:58'),
(8,1,'84.255.203.125','2025-02-18 14:49:50','2025-02-18 14:49:50'),
(9,1,'84.255.203.125','2025-02-18 14:50:07','2025-02-18 14:50:07'),
(10,1,'84.255.203.125','2025-02-18 15:34:37','2025-02-18 15:34:37'),
(11,1,'89.143.131.136','2025-02-21 11:17:12','2025-02-21 11:17:12');
/*!40000 ALTER TABLE `backend_access_log` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `backend_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_user_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_new_user_default` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_unique` (`name`),
  KEY `code_index` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `backend_user_groups` WRITE;
/*!40000 ALTER TABLE `backend_user_groups` DISABLE KEYS */;
REPLACE INTO `backend_user_groups` VALUES
(1,'Owners','2025-02-13 11:01:21','2025-02-13 11:01:21','owners','Default group for website owners.',0);
/*!40000 ALTER TABLE `backend_user_groups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `backend_user_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_user_preferences` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `namespace` varchar(100) NOT NULL,
  `group` varchar(50) NOT NULL,
  `item` varchar(150) NOT NULL,
  `value` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_item_index` (`user_id`,`namespace`,`group`,`item`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `backend_user_preferences` WRITE;
/*!40000 ALTER TABLE `backend_user_preferences` DISABLE KEYS */;
REPLACE INTO `backend_user_preferences` VALUES
(1,1,'backend','reportwidgets','dashboard','{\"welcome\":{\"class\":\"Backend\\\\ReportWidgets\\\\Welcome\",\"sortOrder\":50,\"configuration\":{\"ocWidgetWidth\":7}},\"systemStatus\":{\"class\":\"System\\\\ReportWidgets\\\\Status\",\"sortOrder\":60,\"configuration\":{\"ocWidgetWidth\":7}},\"activeTheme\":{\"class\":\"Cms\\\\ReportWidgets\\\\ActiveTheme\",\"sortOrder\":70,\"configuration\":{\"title\":\"Website\",\"ocWidgetWidth\":5,\"ocWidgetNewRow\":null}}}');
/*!40000 ALTER TABLE `backend_user_preferences` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `backend_user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_user_roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `permissions` text DEFAULT NULL,
  `is_system` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_unique` (`name`),
  KEY `role_code_index` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `backend_user_roles` WRITE;
/*!40000 ALTER TABLE `backend_user_roles` DISABLE KEYS */;
REPLACE INTO `backend_user_roles` VALUES
(1,'Publisher','publisher','Site editor with access to publishing tools.','',1,'2025-02-13 11:01:21','2025-02-13 11:01:21'),
(2,'Developer','developer','Site administrator with access to developer tools.','',1,'2025-02-13 11:01:21','2025-02-13 11:01:21');
/*!40000 ALTER TABLE `backend_user_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `backend_user_throttle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_user_throttle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `last_attempt_at` timestamp NULL DEFAULT NULL,
  `is_suspended` tinyint(1) NOT NULL DEFAULT 0,
  `suspended_at` timestamp NULL DEFAULT NULL,
  `is_banned` tinyint(1) NOT NULL DEFAULT 0,
  `banned_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `backend_user_throttle_user_id_index` (`user_id`),
  KEY `backend_user_throttle_ip_address_index` (`ip_address`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `backend_user_throttle` WRITE;
/*!40000 ALTER TABLE `backend_user_throttle` DISABLE KEYS */;
REPLACE INTO `backend_user_throttle` VALUES
(1,1,'89.143.131.136',0,NULL,0,NULL,0,NULL),
(2,1,'84.255.203.125',0,NULL,0,NULL,0,NULL),
(3,1,'93.138.51.202',0,NULL,0,NULL,0,NULL),
(4,1,'93.138.132.99',0,NULL,0,NULL,0,NULL),
(5,1,'93.138.114.180',0,NULL,0,NULL,0,NULL),
(6,1,'93.136.143.24',0,NULL,0,NULL,0,NULL),
(7,1,'89.143.131.90',0,NULL,0,NULL,0,NULL),
(8,1,'93.138.50.117',0,NULL,0,NULL,0,NULL),
(9,1,'93.138.110.152',0,NULL,0,NULL,0,NULL),
(10,1,'89.143.132.246',0,NULL,0,NULL,0,NULL),
(11,1,'45.135.232.10',3,'2025-09-13 12:18:11',0,NULL,0,NULL);
/*!40000 ALTER TABLE `backend_user_throttle` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `backend_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `login` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `activation_code` varchar(255) DEFAULT NULL,
  `persist_code` varchar(255) DEFAULT NULL,
  `reset_password_code` varchar(255) DEFAULT NULL,
  `permissions` text DEFAULT NULL,
  `metadata` mediumtext DEFAULT NULL,
  `is_activated` tinyint(1) NOT NULL DEFAULT 0,
  `role_id` int(10) unsigned DEFAULT NULL,
  `activated_at` timestamp NULL DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login_unique` (`login`),
  UNIQUE KEY `email_unique` (`email`),
  KEY `act_code_index` (`activation_code`),
  KEY `reset_code_index` (`reset_password_code`),
  KEY `admin_role_index` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `backend_users` WRITE;
/*!40000 ALTER TABLE `backend_users` DISABLE KEYS */;
REPLACE INTO `backend_users` VALUES
(1,'Admin','Developer','admin','admin@numencode.com','$2y$10$28v6SlKR03mX3Ojf29Fg6uQHGYMwChDS8.oggLBgXK0AYAj4W9wVe',NULL,'$2y$10$1zh226vMmKfixBRGu2gwf.LPHFnmYzP58FrTRlA8UMZwMy.f/1M1y',NULL,'',NULL,1,2,NULL,'2025-02-21 11:17:12','2025-02-13 11:01:21','2025-02-21 11:17:12',NULL,1);
/*!40000 ALTER TABLE `backend_users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `backend_users_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_users_groups` (
  `user_id` int(10) unsigned NOT NULL,
  `user_group_id` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`,`user_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `backend_users_groups` WRITE;
/*!40000 ALTER TABLE `backend_users_groups` DISABLE KEYS */;
REPLACE INTO `backend_users_groups` VALUES
(1,1,NULL);
/*!40000 ALTER TABLE `backend_users_groups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` longtext NOT NULL,
  `expiration` int(11) NOT NULL,
  UNIQUE KEY `cache_key_unique` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cms_theme_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cms_theme_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `theme` varchar(255) DEFAULT NULL,
  `data` mediumtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cms_theme_data_theme_index` (`theme`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cms_theme_data` WRITE;
/*!40000 ALTER TABLE `cms_theme_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `cms_theme_data` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cms_theme_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cms_theme_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `theme` varchar(255) DEFAULT NULL,
  `template` varchar(255) DEFAULT NULL,
  `old_template` varchar(255) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `old_content` longtext DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cms_theme_logs_type_index` (`type`),
  KEY `cms_theme_logs_theme_index` (`theme`),
  KEY `cms_theme_logs_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cms_theme_logs` WRITE;
/*!40000 ALTER TABLE `cms_theme_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `cms_theme_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cms_theme_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cms_theme_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `source` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `file_size` int(10) unsigned NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cms_theme_templates_source_index` (`source`),
  KEY `cms_theme_templates_path_index` (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cms_theme_templates` WRITE;
/*!40000 ALTER TABLE `cms_theme_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `cms_theme_templates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `deferred_bindings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `deferred_bindings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `master_type` varchar(255) NOT NULL,
  `master_field` varchar(255) NOT NULL,
  `slave_type` varchar(255) NOT NULL,
  `slave_id` varchar(255) NOT NULL,
  `pivot_data` mediumtext DEFAULT NULL,
  `session_key` varchar(255) NOT NULL,
  `is_bind` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `deferred_bindings_master_type_index` (`master_type`),
  KEY `deferred_bindings_master_field_index` (`master_field`),
  KEY `deferred_bindings_slave_type_index` (`slave_type`),
  KEY `deferred_bindings_slave_id_index` (`slave_id`),
  KEY `deferred_bindings_session_key_index` (`session_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `deferred_bindings` WRITE;
/*!40000 ALTER TABLE `deferred_bindings` DISABLE KEYS */;
/*!40000 ALTER TABLE `deferred_bindings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) DEFAULT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext DEFAULT NULL,
  `failed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_reserved_at_index` (`queue`,`reserved_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
REPLACE INTO `migrations` VALUES
(1,'2013_10_01_000001_Db_Deferred_Bindings',1),
(2,'2013_10_01_000002_Db_System_Files',1),
(3,'2013_10_01_000003_Db_System_Plugin_Versions',1),
(4,'2013_10_01_000004_Db_System_Plugin_History',1),
(5,'2013_10_01_000005_Db_System_Settings',1),
(6,'2013_10_01_000006_Db_System_Parameters',1),
(7,'2013_10_01_000007_Db_System_Add_Disabled_Flag',1),
(8,'2013_10_01_000008_Db_System_Mail_Templates',1),
(9,'2013_10_01_000009_Db_System_Mail_Layouts',1),
(10,'2014_10_01_000010_Db_Jobs',1),
(11,'2014_10_01_000011_Db_System_Event_Logs',1),
(12,'2014_10_01_000012_Db_System_Request_Logs',1),
(13,'2014_10_01_000013_Db_System_Sessions',1),
(14,'2015_10_01_000014_Db_System_Mail_Layout_Rename',1),
(15,'2015_10_01_000015_Db_System_Add_Frozen_Flag',1),
(16,'2015_10_01_000016_Db_Cache',1),
(17,'2015_10_01_000017_Db_System_Revisions',1),
(18,'2015_10_01_000018_Db_FailedJobs',1),
(19,'2016_10_01_000019_Db_System_Plugin_History_Detail_Text',1),
(20,'2016_10_01_000020_Db_System_Timestamp_Fix',1),
(21,'2017_08_04_121309_Db_Deferred_Bindings_Add_Index_Session',1),
(22,'2017_10_01_000021_Db_System_Sessions_Update',1),
(23,'2017_10_01_000022_Db_Jobs_FailedJobs_Update',1),
(24,'2017_10_01_000023_Db_System_Mail_Partials',1),
(25,'2017_10_23_000024_Db_System_Mail_Layouts_Add_Options_Field',1),
(26,'2021_10_01_000025_Db_Add_Pivot_Data_To_Deferred_Bindings',1),
(27,'2022_08_06_000026_Db_System_Add_App_Birthday_Date',1),
(28,'2022_10_14_000027_Db_Jobs_FailedJobs_Update',1),
(29,'2023_09_24_000028_Db_System_Sessions_Indexes',1),
(30,'2023_10_20_000029_Db_Jobs_Batches',1),
(31,'2013_10_01_000001_Db_Backend_Users',2),
(32,'2013_10_01_000002_Db_Backend_User_Groups',2),
(33,'2013_10_01_000003_Db_Backend_Users_Groups',2),
(34,'2013_10_01_000004_Db_Backend_User_Throttle',2),
(35,'2014_01_04_000005_Db_Backend_User_Preferences',2),
(36,'2014_10_01_000006_Db_Backend_Access_Log',2),
(37,'2014_10_01_000007_Db_Backend_Add_Description_Field',2),
(38,'2015_10_01_000008_Db_Backend_Add_Superuser_Flag',2),
(39,'2016_10_01_000009_Db_Backend_Timestamp_Fix',2),
(40,'2017_10_01_000010_Db_Backend_User_Roles',2),
(41,'2018_12_16_000011_Db_Backend_Add_Deleted_At',2),
(42,'2023_02_16_000012_Db_Backend_Add_User_Metadata',2),
(43,'2023_09_09_000013_Db_Backend_Add_Users_Groups_Delete_At',2),
(44,'2014_10_01_000001_Db_Cms_Theme_Data',3),
(45,'2016_10_01_000002_Db_Cms_Timestamp_Fix',3),
(46,'2017_10_01_000003_Db_Cms_Theme_Logs',3),
(47,'2018_11_01_000001_Db_Cms_Theme_Templates',3),
(48,'2025_04_10_000031_Db_Add_System_Files_Metadata',4);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `numencode_widgets_features_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `numencode_widgets_features_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `link_title` varchar(255) DEFAULT NULL,
  `is_published` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `numencode_widgets_features_groups` WRITE;
/*!40000 ALTER TABLE `numencode_widgets_features_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `numencode_widgets_features_groups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `numencode_widgets_features_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `numencode_widgets_features_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `link_title` varchar(255) DEFAULT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `is_published` tinyint(1) NOT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `numencode_widgets_features_items_group_id_index` (`group_id`),
  CONSTRAINT `numencode_widgets_features_items_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `numencode_widgets_features_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `numencode_widgets_features_items` WRITE;
/*!40000 ALTER TABLE `numencode_widgets_features_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `numencode_widgets_features_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `numencode_widgets_gallery_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `numencode_widgets_gallery_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `link_title` varchar(255) DEFAULT NULL,
  `is_published` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `numencode_widgets_gallery_groups` WRITE;
/*!40000 ALTER TABLE `numencode_widgets_gallery_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `numencode_widgets_gallery_groups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `numencode_widgets_gallery_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `numencode_widgets_gallery_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `is_published` tinyint(1) NOT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `numencode_widgets_gallery_items_group_id_index` (`group_id`),
  CONSTRAINT `numencode_widgets_gallery_items_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `numencode_widgets_gallery_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `numencode_widgets_gallery_items` WRITE;
/*!40000 ALTER TABLE `numencode_widgets_gallery_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `numencode_widgets_gallery_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `numencode_widgets_highlights_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `numencode_widgets_highlights_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `link_title` varchar(255) DEFAULT NULL,
  `is_published` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `numencode_widgets_highlights_groups` WRITE;
/*!40000 ALTER TABLE `numencode_widgets_highlights_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `numencode_widgets_highlights_groups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `numencode_widgets_highlights_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `numencode_widgets_highlights_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `link_title` varchar(255) DEFAULT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `is_published` tinyint(1) NOT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `numencode_widgets_highlights_items_group_id_index` (`group_id`),
  CONSTRAINT `numencode_widgets_highlights_items_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `numencode_widgets_highlights_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `numencode_widgets_highlights_items` WRITE;
/*!40000 ALTER TABLE `numencode_widgets_highlights_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `numencode_widgets_highlights_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `numencode_widgets_promotions_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `numencode_widgets_promotions_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `link_title` varchar(255) DEFAULT NULL,
  `is_published` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `numencode_widgets_promotions_groups` WRITE;
/*!40000 ALTER TABLE `numencode_widgets_promotions_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `numencode_widgets_promotions_groups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `numencode_widgets_promotions_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `numencode_widgets_promotions_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `link_title` varchar(255) DEFAULT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `is_published` tinyint(1) NOT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `numencode_widgets_promotions_items_group_id_index` (`group_id`),
  CONSTRAINT `numencode_widgets_promotions_items_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `numencode_widgets_promotions_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `numencode_widgets_promotions_items` WRITE;
/*!40000 ALTER TABLE `numencode_widgets_promotions_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `numencode_widgets_promotions_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `payload` text DEFAULT NULL,
  `last_activity` int(11) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`),
  KEY `sessions_last_activity_index` (`last_activity`),
  KEY `sessions_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `system_event_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_event_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `level` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_event_logs_level_index` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `system_event_logs` WRITE;
/*!40000 ALTER TABLE `system_event_logs` DISABLE KEYS */;
REPLACE INTO `system_event_logs` VALUES
(1,'error','Error: Call to undefined function Symfony\\Component\\Mailer\\Transport\\Smtp\\Stream\\proc_open() in /home/webarea/web/webarea.eu/public_html/vendor/symfony/mailer/Transport/Smtp/Stream/ProcessStream.php:47\nStack trace:\n#0 /home/webarea/web/webarea.eu/public_html/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php(275): Symfony\\Component\\Mailer\\Transport\\Smtp\\Stream\\ProcessStream->initialize()\n#1 /home/webarea/web/webarea.eu/public_html/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php(210): Symfony\\Component\\Mailer\\Transport\\Smtp\\SmtpTransport->start()\n#2 /home/webarea/web/webarea.eu/public_html/vendor/symfony/mailer/Transport/AbstractTransport.php(69): Symfony\\Component\\Mailer\\Transport\\Smtp\\SmtpTransport->doSend()\n#3 /home/webarea/web/webarea.eu/public_html/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php(137): Symfony\\Component\\Mailer\\Transport\\AbstractTransport->send()\n#4 /home/webarea/web/webarea.eu/public_html/vendor/symfony/mailer/Transport/SendmailTransport.php(75): Symfony\\Component\\Mailer\\Transport\\Smtp\\SmtpTransport->send()\n#5 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(523): Symfony\\Component\\Mailer\\Transport\\SendmailTransport->send()\n#6 /home/webarea/web/webarea.eu/public_html/vendor/winter/storm/src/Mail/Mailer.php(157): Illuminate\\Mail\\Mailer->sendSymfonyMessage()\n#7 /home/webarea/web/webarea.eu/public_html/vendor/winter/storm/src/Mail/Mailer.php(40): Winter\\Storm\\Mail\\Mailer->send()\n#8 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(338): Winter\\Storm\\Mail\\Mailer->raw()\n#9 /home/webarea/web/webarea.eu/public_html/modules/system/controllers/Settings.php(133): Illuminate\\Support\\Facades\\Facade::__callStatic()\n#10 [internal function]: System\\Controllers\\Settings->update_onTest()\n#11 /home/webarea/web/webarea.eu/public_html/modules/backend/classes/Controller.php(631): call_user_func_array()\n#12 /home/webarea/web/webarea.eu/public_html/modules/backend/classes/Controller.php(489): Backend\\Classes\\Controller->runAjaxHandler()\n#13 /home/webarea/web/webarea.eu/public_html/modules/backend/classes/Controller.php(287): Backend\\Classes\\Controller->execAjaxHandlers()\n#14 /home/webarea/web/webarea.eu/public_html/modules/backend/classes/BackendController.php(161): Backend\\Classes\\Controller->run()\n#15 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Routing/Controller.php(54): Backend\\Classes\\BackendController->run()\n#16 /home/webarea/web/webarea.eu/public_html/modules/backend/classes/BackendController.php(111): Illuminate\\Routing\\Controller->callAction()\n#17 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Routing/ControllerDispatcher.php(43): Backend\\Classes\\BackendController->callAction()\n#18 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Routing/Route.php(259): Illuminate\\Routing\\ControllerDispatcher->dispatch()\n#19 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Routing/Route.php(205): Illuminate\\Routing\\Route->runController()\n#20 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(798): Illuminate\\Routing\\Route->run()\n#21 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(141): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}()\n#22 /home/webarea/web/webarea.eu/public_html/modules/backend/classes/BackendController.php(68): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#23 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(162): Backend\\Classes\\BackendController->Backend\\Classes\\{closure}()\n#24 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Routing/Middleware/SubstituteBindings.php(50): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#25 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle()\n#26 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/View/Middleware/ShareErrorsFromSession.php(49): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#27 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle()\n#28 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(121): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#29 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(64): Illuminate\\Session\\Middleware\\StartSession->handleStatefulRequest()\n#30 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Session\\Middleware\\StartSession->handle()\n#31 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(37): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#32 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle()\n#33 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(67): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#34 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle()\n#35 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(116): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#36 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(797): Illuminate\\Pipeline\\Pipeline->then()\n#37 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(776): Illuminate\\Routing\\Router->runRouteWithinStack()\n#38 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(740): Illuminate\\Routing\\Router->runRoute()\n#39 /home/webarea/web/webarea.eu/public_html/vendor/winter/storm/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute()\n#40 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(190): Winter\\Storm\\Router\\CoreRouter->dispatch()\n#41 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(141): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}()\n#42 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/PreventRequestsDuringMaintenance.php(86): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#43 /home/webarea/web/webarea.eu/public_html/vendor/winter/storm/src/Foundation/Http/Middleware/CheckForMaintenanceMode.php(25): Illuminate\\Foundation\\Http\\Middleware\\PreventRequestsDuringMaintenance->handle()\n#44 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Winter\\Storm\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#45 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Http/Middleware/HandleCors.php(49): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#46 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Http\\Middleware\\HandleCors->handle()\n#47 /home/webarea/web/webarea.eu/public_html/vendor/winter/storm/src/Foundation/Http/Middleware/CheckForTrustedProxies.php(56): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#48 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Winter\\Storm\\Foundation\\Http\\Middleware\\CheckForTrustedProxies->handle()\n#49 /home/webarea/web/webarea.eu/public_html/vendor/winter/storm/src/Http/Middleware/TrustHosts.php(46): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#50 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Winter\\Storm\\Http\\Middleware\\TrustHosts->handle()\n#51 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(116): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#52 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(165): Illuminate\\Pipeline\\Pipeline->then()\n#53 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(134): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter()\n#54 /home/webarea/web/webarea.eu/public_html/index.php(42): Illuminate\\Foundation\\Http\\Kernel->handle()\n#55 {main}','[]','2025-02-13 13:17:12','2025-02-13 13:17:12'),
(2,'error','Error: Call to undefined function Symfony\\Component\\Mailer\\Transport\\Smtp\\Stream\\proc_open() in /home/webarea/web/webarea.eu/public_html/vendor/symfony/mailer/Transport/Smtp/Stream/ProcessStream.php:47\nStack trace:\n#0 /home/webarea/web/webarea.eu/public_html/vendor/symfony/mailer/Transport/SendmailTransport.php(115): Symfony\\Component\\Mailer\\Transport\\Smtp\\Stream\\ProcessStream->initialize()\n#1 /home/webarea/web/webarea.eu/public_html/vendor/symfony/mailer/Transport/AbstractTransport.php(69): Symfony\\Component\\Mailer\\Transport\\SendmailTransport->doSend()\n#2 /home/webarea/web/webarea.eu/public_html/vendor/symfony/mailer/Transport/SendmailTransport.php(78): Symfony\\Component\\Mailer\\Transport\\AbstractTransport->send()\n#3 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(523): Symfony\\Component\\Mailer\\Transport\\SendmailTransport->send()\n#4 /home/webarea/web/webarea.eu/public_html/vendor/winter/storm/src/Mail/Mailer.php(157): Illuminate\\Mail\\Mailer->sendSymfonyMessage()\n#5 /home/webarea/web/webarea.eu/public_html/vendor/winter/storm/src/Mail/Mailer.php(40): Winter\\Storm\\Mail\\Mailer->send()\n#6 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(338): Winter\\Storm\\Mail\\Mailer->raw()\n#7 /home/webarea/web/webarea.eu/public_html/modules/system/controllers/Settings.php(133): Illuminate\\Support\\Facades\\Facade::__callStatic()\n#8 [internal function]: System\\Controllers\\Settings->update_onTest()\n#9 /home/webarea/web/webarea.eu/public_html/modules/backend/classes/Controller.php(631): call_user_func_array()\n#10 /home/webarea/web/webarea.eu/public_html/modules/backend/classes/Controller.php(489): Backend\\Classes\\Controller->runAjaxHandler()\n#11 /home/webarea/web/webarea.eu/public_html/modules/backend/classes/Controller.php(287): Backend\\Classes\\Controller->execAjaxHandlers()\n#12 /home/webarea/web/webarea.eu/public_html/modules/backend/classes/BackendController.php(161): Backend\\Classes\\Controller->run()\n#13 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Routing/Controller.php(54): Backend\\Classes\\BackendController->run()\n#14 /home/webarea/web/webarea.eu/public_html/modules/backend/classes/BackendController.php(111): Illuminate\\Routing\\Controller->callAction()\n#15 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Routing/ControllerDispatcher.php(43): Backend\\Classes\\BackendController->callAction()\n#16 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Routing/Route.php(259): Illuminate\\Routing\\ControllerDispatcher->dispatch()\n#17 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Routing/Route.php(205): Illuminate\\Routing\\Route->runController()\n#18 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(798): Illuminate\\Routing\\Route->run()\n#19 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(141): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}()\n#20 /home/webarea/web/webarea.eu/public_html/modules/backend/classes/BackendController.php(68): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#21 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(162): Backend\\Classes\\BackendController->Backend\\Classes\\{closure}()\n#22 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Routing/Middleware/SubstituteBindings.php(50): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#23 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle()\n#24 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/View/Middleware/ShareErrorsFromSession.php(49): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#25 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle()\n#26 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(121): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#27 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(64): Illuminate\\Session\\Middleware\\StartSession->handleStatefulRequest()\n#28 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Session\\Middleware\\StartSession->handle()\n#29 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(37): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#30 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle()\n#31 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(67): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#32 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle()\n#33 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(116): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#34 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(797): Illuminate\\Pipeline\\Pipeline->then()\n#35 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(776): Illuminate\\Routing\\Router->runRouteWithinStack()\n#36 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Routing/Router.php(740): Illuminate\\Routing\\Router->runRoute()\n#37 /home/webarea/web/webarea.eu/public_html/vendor/winter/storm/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute()\n#38 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(190): Winter\\Storm\\Router\\CoreRouter->dispatch()\n#39 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(141): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}()\n#40 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/PreventRequestsDuringMaintenance.php(86): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#41 /home/webarea/web/webarea.eu/public_html/vendor/winter/storm/src/Foundation/Http/Middleware/CheckForMaintenanceMode.php(25): Illuminate\\Foundation\\Http\\Middleware\\PreventRequestsDuringMaintenance->handle()\n#42 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Winter\\Storm\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()\n#43 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Http/Middleware/HandleCors.php(49): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#44 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Illuminate\\Http\\Middleware\\HandleCors->handle()\n#45 /home/webarea/web/webarea.eu/public_html/vendor/winter/storm/src/Foundation/Http/Middleware/CheckForTrustedProxies.php(56): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#46 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Winter\\Storm\\Foundation\\Http\\Middleware\\CheckForTrustedProxies->handle()\n#47 /home/webarea/web/webarea.eu/public_html/vendor/winter/storm/src/Http/Middleware/TrustHosts.php(46): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#48 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(180): Winter\\Storm\\Http\\Middleware\\TrustHosts->handle()\n#49 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(116): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()\n#50 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(165): Illuminate\\Pipeline\\Pipeline->then()\n#51 /home/webarea/web/webarea.eu/public_html/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(134): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter()\n#52 /home/webarea/web/webarea.eu/public_html/index.php(42): Illuminate\\Foundation\\Http\\Kernel->handle()\n#53 {main}','[]','2025-02-13 13:17:23','2025-02-13 13:17:23'),
(3,'debug','From: WebArea <info@webarea.eu>\r\nTo: Admin Developer <admin@numencode.com>\r\nSubject: Mail driver test\r\nMIME-Version: 1.0\r\nDate: Thu, 13 Feb 2025 14:17:31 +0000\r\nMessage-ID: <2040645a889a32cc95045f22c0b9bae5@webarea.eu>\r\nContent-Type: multipart/alternative; boundary=po59-aCZ\r\n\r\n--po59-aCZ\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Transfer-Encoding: quoted-printable\r\n\r\nThis is a test email to confirm that the provided mail settings work.\r\n--po59-aCZ\r\nContent-Type: text/html; charset=utf-8\r\nContent-Transfer-Encoding: quoted-printable\r\n\r\n<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.=\r\nw3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\r\n<html xmlns=3D\"http://www.=\r\nw3.org/1999/xhtml\">\r\n<head>\r\n    <meta name=3D\"viewport\" content=3D\"width=\r\n=3Ddevice-width, initial-scale=3D1.0\">\r\n    <meta http-equiv=3D\"Content-Ty=\r\npe\" content=3D\"text/html; charset=3DUTF-8\">\r\n    <style type=3D\"text/css\" =\r\nmedia=3D\"screen\">\r\n        body,body *:not(html):not(style):not(br):not(tr=\r\n):not(code){font-family:Avenir,Helvetica,sans-serif;box-sizing:border-box}b=\r\nody{background-color:#f5f8fa;color:#74787e;height:100%;hyphens:auto;line-he=\r\night:1.4;margin:0;-moz-hyphens:auto;-ms-word-break:break-word;width:100% !i=\r\nmportant;-webkit-hyphens:auto;-webkit-text-size-adjust:none;word-break:brea=\r\nk-word}p,ul,ol,blockquote{line-height:1.4;text-align:left}a{color:#0181b9}a=\r\n img{border:none}h1{color:#2f3133;font-size:19px;font-weight:bold;margin-to=\r\np:0;text-align:left}h2{color:#2f3133;font-size:16px;font-weight:bold;margin=\r\n-top:0;text-align:left}h3{color:#2f3133;font-size:14px;font-weight:bold;mar=\r\ngin-top:0;text-align:left}p{color:#74787e;font-size:16px;line-height:1.5em;=\r\nmargin-top:0;text-align:left}code{color:#74787e;font-size:16px;line-height:=\r\n1.5em;word-break:break-all}p.sub{font-size:12px}img{max-width:100%}.break-a=\r\nll,.break-all *{word-break:break-all}.wrapper{background-color:#f5f8fa;marg=\r\nin:0;padding:0;width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0=\r\n;-premailer-width:100%}.content{margin:0;padding:0;width:100%;-premailer-ce=\r\nllpadding:0;-premailer-cellspacing:0;-premailer-width:100%}.header{padding:=\r\n25px 0;text-align:center}.header a,.header span{color:#bbbfc3;font-size:19p=\r\nx;font-weight:bold;text-decoration:none}.body{background-color:#fff;border-=\r\nbottom:1px solid #edeff2;border-top:1px solid #edeff2;margin:0;padding:0;wi=\r\ndth:100%;-premailer-cellpadding:0;-premailer-cellspacing:0;-premailer-width=\r\n:100%}.inner-body{background-color:#fff;margin:0 auto;padding:0;width:570px=\r\n;-premailer-cellpadding:0;-premailer-cellspacing:0;-premailer-width:570px}.=\r\nsubcopy{border-top:1px solid #edeff2;margin-top:25px;padding-top:25px}.subc=\r\nopy p{font-size:12px}.footer{margin:0 auto;padding:0;text-align:center;widt=\r\nh:570px;-premailer-cellpadding:0;-premailer-cellspacing:0;-premailer-width:=\r\n570px}.footer p{color:#aeaeae;font-size:12px;text-align:center}.table table=\r\n{border-collapse:collapse;margin:30px auto;width:100%;-premailer-cellpaddin=\r\ng:0;-premailer-cellspacing:0;-premailer-width:100%}.table th{border-bottom:=\r\n1px solid #edeff2;padding-bottom:8px}.table td{color:#74787e;font-size:15px=\r\n;line-height:18px;padding:10px 0}.content-cell{padding:35px}.wrapper.layout=\r\n-system .content-cell{padding:35px 0}.action{margin:30px auto;padding:0;tex=\r\nt-align:center;width:100%;-premailer-cellpadding:0;-premailer-cellspacing:0=\r\n;-premailer-width:100%}.button{border-radius:3px;box-shadow:0 2px 3px rgba(=\r\n0,0,0,0.16);color:#fff;display:inline-block;text-decoration:none;-webkit-te=\r\nxt-size-adjust:none}.button-primary{background-color:#3498db;border-top:10p=\r\nx solid #3498db;border-right:18px solid #3498db;border-bottom:10px solid #3=\r\n498db;border-left:18px solid #3498db}.button-positive{background-color:#31a=\r\nc5f;border-top:10px solid #31ac5f;border-right:18px solid #31ac5f;border-bo=\r\nttom:10px solid #31ac5f;border-left:18px solid #31ac5f}.button-negative{bac=\r\nkground-color:#ab2a1c;border-top:10px solid #ab2a1c;border-right:18px solid=\r\n #ab2a1c;border-bottom:10px solid #ab2a1c;border-left:18px solid #ab2a1c}.p=\r\nanel{margin:0 0 21px}.panel-content{background-color:#edeff2;padding:16px}.=\r\npanel-item{padding:0}.panel-item p:last-of-type{margin-bottom:0;padding-bot=\r\ntom:0}.promotion{background-color:#fff;border:2px dashed #9ba2ab;margin:0;m=\r\nargin-bottom:25px;margin-top:25px;padding:24px;width:100%;-premailer-cellpa=\r\ndding:0;-premailer-cellspacing:0;-premailer-width:100%}.promotion h1{text-a=\r\nlign:center}.promotion p{font-size:15px;text-align:center}.promotion p:last=\r\n-of-type{margin-bottom:0;padding-bottom:0}\r\n        @media only screen and=\r\n (max-width: 600px) {\r\n    .inner-body {\r\n        width: 100% !important;=\r\n\r\n    }\r\n\r\n    .footer {\r\n        width: 100% !important;\r\n    }\r\n}=\r\n\r\n\r\n@media only screen and (max-width: 500px) {\r\n    .button {\r\n       =\r\n width: 100% !important;\r\n    }\r\n}\r\n    </style>\r\n</head>\r\n<body style=\r\n=3D\"font-family: Avenir,Helvetica,sans-serif; box-sizing: border-box; backg=\r\nround-color: #f5f8fa; color: #74787e; height: 100%; hyphens: auto; line-hei=\r\nght: 1.4; margin: 0; -moz-hyphens: auto; -ms-word-break: break-word; width:=\r\n 100% !important; -webkit-hyphens: auto; -webkit-text-size-adjust: none; wo=\r\nrd-break: break-word;\">\r\n    <table class=3D\"wrapper layout-default\" width=\r\n=3D\"100%\" cellpadding=3D\"0\" cellspacing=3D\"0\" style=3D\"font-family: Avenir,=\r\nHelvetica,sans-serif; box-sizing: border-box; background-color: #f5f8fa; ma=\r\nrgin: 0; padding: 0; width: 100%; -premailer-cellpadding: 0; -premailer-cel=\r\nlspacing: 0; -premailer-width: 100%;\">\r\n\r\n        <!-- Header -->\r\n     =\r\n   <tr>\r\n    <td class=3D\"header\" style=3D\"font-family: Avenir,Helvetica,s=\r\nans-serif; box-sizing: border-box; padding: 25px 0; text-align: center;\">=\r\n\r\n                    <span style=3D\"font-family: Avenir,Helvetica,sans-se=\r\nrif; box-sizing: border-box; color: #bbbfc3; font-size: 19px; font-weight: =\r\nbold; text-decoration: none;\">\r\n                            Mail driver te=\r\nst\r\n       =20\r\n            </span>\r\n            </td>\r\n</tr>\r\n        <=\r\ntr>\r\n            <td align=3D\"center\" style=3D\"font-family: Avenir,Helveti=\r\nca,sans-serif; box-sizing: border-box;\">\r\n                <table class=3D\"=\r\ncontent\" width=3D\"100%\" cellpadding=3D\"0\" cellspacing=3D\"0\" style=3D\"font-f=\r\namily: Avenir,Helvetica,sans-serif; box-sizing: border-box; margin: 0; padd=\r\ning: 0; width: 100%; -premailer-cellpadding: 0; -premailer-cellspacing: 0; =\r\n-premailer-width: 100%;\">\r\n                    <!-- Email Body -->\r\n     =\r\n               <tr>\r\n                        <td class=3D\"body\" width=3D\"1=\r\n00%\" cellpadding=3D\"0\" cellspacing=3D\"0\" style=3D\"font-family: Avenir,Helve=\r\ntica,sans-serif; box-sizing: border-box; background-color: #fff; border-bot=\r\ntom: 1px solid #edeff2; border-top: 1px solid #edeff2; margin: 0; padding: =\r\n0; width: 100%; -premailer-cellpadding: 0; -premailer-cellspacing: 0; -prem=\r\nailer-width: 100%;\">\r\n                            <table class=3D\"inner-bo=\r\ndy\" align=3D\"center\" width=3D\"570\" cellpadding=3D\"0\" cellspacing=3D\"0\" styl=\r\ne=3D\"font-family: Avenir,Helvetica,sans-serif; box-sizing: border-box; back=\r\nground-color: #fff; margin: 0 auto; padding: 0; width: 570px; -premailer-ce=\r\nllpadding: 0; -premailer-cellspacing: 0; -premailer-width: 570px;\">\r\n     =\r\n                           <!-- Body content -->\r\n                        =\r\n        <tr>\r\n                                    <td class=3D\"content-cel=\r\nl\" style=3D\"font-family: Avenir,Helvetica,sans-serif; box-sizing: border-bo=\r\nx; padding: 35px;\">\r\n                                        <p style=3D\"f=\r\nont-family: Avenir,Helvetica,sans-serif; box-sizing: border-box; color: #74=\r\n787e; font-size: 16px; line-height: 1.5em; margin-top: 0; text-align: left;=\r\n\">This is a test email to confirm that the provided mail settings work.</p>=\r\n\r\n\r\n                                    </td>\r\n                         =\r\n       </tr>\r\n                            </table>\r\n                     =\r\n   </td>\r\n                    </tr>\r\n                </table>\r\n         =\r\n   </td>\r\n        </tr>\r\n\r\n        <!-- Footer -->\r\n        <tr>\r\n    =\r\n<td style=3D\"font-family: Avenir,Helvetica,sans-serif; box-sizing: border-b=\r\nox;\">\r\n        <table class=3D\"footer\" align=3D\"center\" width=3D\"570\" cell=\r\npadding=3D\"0\" cellspacing=3D\"0\" style=3D\"font-family: Avenir,Helvetica,sans=\r\n-serif; box-sizing: border-box; margin: 0 auto; padding: 0; text-align: cen=\r\nter; width: 570px; -premailer-cellpadding: 0; -premailer-cellspacing: 0; -p=\r\nremailer-width: 570px;\">\r\n            <tr>\r\n                <td class=3D\"=\r\ncontent-cell\" align=3D\"center\" style=3D\"font-family: Avenir,Helvetica,sans-=\r\nserif; box-sizing: border-box; padding: 35px;\">\r\n                    <p st=\r\nyle=3D\"font-family: Avenir,Helvetica,sans-serif; box-sizing: border-box; li=\r\nne-height: 1.5em; margin-top: 0; color: #aeaeae; font-size: 12px; text-alig=\r\nn: center;\">=C2=A9 2025 WebArea. All rights reserved.</p>\r\n\r\n            =\r\n    </td>\r\n            </tr>\r\n        </table>\r\n    </td>\r\n</tr>\r\n    =\r\n</table>\r\n\r\n</body>\r\n</html>\r\n--po59-aCZ--','[]','2025-02-13 13:17:31','2025-02-13 13:17:31'),
(4,'info','No upgrade of Winter.Redirect needed. Fresh installation.','[]','2025-08-02 11:05:51','2025-08-02 11:05:51'),
(5,'info','No sitemap definition was found. Try creating one first.','[]','2025-08-06 03:33:18','2025-08-06 03:33:18'),
(6,'info','No sitemap definition was found. Try creating one first.','[]','2025-08-08 15:20:30','2025-08-08 15:20:30'),
(7,'info','No sitemap definition was found. Try creating one first.','[]','2025-08-08 16:21:35','2025-08-08 16:21:35'),
(8,'info','No sitemap definition was found. Try creating one first.','[]','2025-08-18 15:47:22','2025-08-18 15:47:22'),
(9,'info','No sitemap definition was found. Try creating one first.','[]','2025-08-18 16:52:15','2025-08-18 16:52:15'),
(10,'info','No sitemap definition was found. Try creating one first.','[]','2025-08-21 11:31:41','2025-08-21 11:31:41'),
(11,'info','No sitemap definition was found. Try creating one first.','[]','2025-09-02 12:01:56','2025-09-02 12:01:56'),
(12,'info','No sitemap definition was found. Try creating one first.','[]','2025-09-08 13:39:38','2025-09-08 13:39:38'),
(13,'error','NumenCode\\SyncOps\\Console\\MediaPush::handle(): Return value must be of type int, none returned','{\"logVersion\":2,\"exception\":{\"type\":\"TypeError\",\"message\":\"NumenCode\\\\SyncOps\\\\Console\\\\MediaPush::handle(): Return value must be of type int, none returned\",\"file\":\"\\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/plugins\\/numencode\\/syncops\\/console\\/MediaPush.php\",\"line\":73,\"snippet\":{\"67\":\"        }\\n\",\"68\":\"\\n\",\"69\":\"        $bar->finish();\\n\",\"70\":\"\\n\",\"71\":\"        $this->info(PHP_EOL . \\\"\\u2714 All media files have been successfully uploaded.\\\");\\n\",\"72\":\"    }\\n\",\"73\":\"\\n\",\"74\":\"    protected function resolveFolderName(?string $folderName): string\\n\",\"75\":\"    {\\n\",\"76\":\"        return $folderName ? rtrim($folderName, \'\\/\') . \'\\/\' : \'storage\\/\';\\n\",\"77\":\"    }\\n\",\"78\":\"\\n\"},\"trace\":[{\"file\":\"\\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php\",\"line\":36,\"function\":\"handle\",\"class\":\"NumenCode\\\\SyncOps\\\\Console\\\\MediaPush\",\"type\":\"->\",\"snippet\":{\"30\":\"        if (static::isCallableWithAtSign($callback) || $defaultMethod) {\\n\",\"31\":\"            return static::callClass($container, $callback, $parameters, $defaultMethod);\\n\",\"32\":\"        }\\n\",\"33\":\"\\n\",\"34\":\"        return static::callBoundMethod($container, $callback, function () use ($container, $callback, $parameters) {\\n\",\"35\":\"            return $callback(...array_values(static::getMethodDependencies($container, $callback, $parameters)));\\n\",\"36\":\"        });\\n\",\"37\":\"    }\\n\",\"38\":\"\\n\",\"39\":\"    \\/**\\n\",\"40\":\"     * Call a string reference to a class using Class@method syntax.\\n\",\"41\":\"     *\\n\"},\"in_app\":false,\"arguments\":[]},{\"file\":\"\\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php\",\"line\":41,\"function\":\"Illuminate\\\\Container\\\\{closure}\",\"class\":\"Illuminate\\\\Container\\\\BoundMethod\",\"type\":\"::\",\"snippet\":{\"35\":\"     * @param  mixed  ...$args\\n\",\"36\":\"     * @return mixed\\n\",\"37\":\"     *\\/\\n\",\"38\":\"    public static function unwrapIfClosure($value, ...$args)\\n\",\"39\":\"    {\\n\",\"40\":\"        return $value instanceof Closure ? $value(...$args) : $value;\\n\",\"41\":\"    }\\n\",\"42\":\"\\n\",\"43\":\"    \\/**\\n\",\"44\":\"     * Get the class name of the given parameter\'s type, if possible.\\n\",\"45\":\"     *\\n\",\"46\":\"     * From Reflector::getParameterClassName() in Illuminate\\\\Support.\\n\"},\"in_app\":false,\"arguments\":[]},{\"file\":\"\\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php\",\"line\":93,\"function\":\"unwrapIfClosure\",\"class\":\"Illuminate\\\\Container\\\\Util\",\"type\":\"::\",\"snippet\":{\"87\":\"\\n\",\"88\":\"        if ($container->hasMethodBinding($method)) {\\n\",\"89\":\"            return $container->callMethodBinding($method, $callback[0]);\\n\",\"90\":\"        }\\n\",\"91\":\"\\n\",\"92\":\"        return Util::unwrapIfClosure($default);\\n\",\"93\":\"    }\\n\",\"94\":\"\\n\",\"95\":\"    \\/**\\n\",\"96\":\"     * Normalize the given callback into a Class@method string.\\n\",\"97\":\"     *\\n\",\"98\":\"     * @param  callable  $callback\\n\"},\"in_app\":false,\"arguments\":[]},{\"file\":\"\\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php\",\"line\":35,\"function\":\"callBoundMethod\",\"class\":\"Illuminate\\\\Container\\\\BoundMethod\",\"type\":\"::\",\"snippet\":{\"29\":\"\\n\",\"30\":\"        if (static::isCallableWithAtSign($callback) || $defaultMethod) {\\n\",\"31\":\"            return static::callClass($container, $callback, $parameters, $defaultMethod);\\n\",\"32\":\"        }\\n\",\"33\":\"\\n\",\"34\":\"        return static::callBoundMethod($container, $callback, function () use ($container, $callback, $parameters) {\\n\",\"35\":\"            return $callback(...array_values(static::getMethodDependencies($container, $callback, $parameters)));\\n\",\"36\":\"        });\\n\",\"37\":\"    }\\n\",\"38\":\"\\n\",\"39\":\"    \\/**\\n\",\"40\":\"     * Call a string reference to a class using Class@method syntax.\\n\"},\"in_app\":false,\"arguments\":[]},{\"file\":\"\\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":661,\"function\":\"call\",\"class\":\"Illuminate\\\\Container\\\\BoundMethod\",\"type\":\"::\",\"snippet\":{\"655\":\"            $this->buildStack[] = $className;\\n\",\"656\":\"\\n\",\"657\":\"            $pushedToBuildStack = true;\\n\",\"658\":\"        }\\n\",\"659\":\"\\n\",\"660\":\"        $result = BoundMethod::call($this, $callback, $parameters, $defaultMethod);\\n\",\"661\":\"\\n\",\"662\":\"        if ($pushedToBuildStack) {\\n\",\"663\":\"            array_pop($this->buildStack);\\n\",\"664\":\"        }\\n\",\"665\":\"\\n\",\"666\":\"        return $result;\\n\"},\"in_app\":false,\"arguments\":[]},{\"file\":\"\\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php\",\"line\":183,\"function\":\"call\",\"class\":\"Illuminate\\\\Container\\\\Container\",\"type\":\"->\",\"snippet\":{\"177\":\"        }\\n\",\"178\":\"\\n\",\"179\":\"        $method = method_exists($this, \'handle\') ? \'handle\' : \'__invoke\';\\n\",\"180\":\"\\n\",\"181\":\"        try {\\n\",\"182\":\"            return (int) $this->laravel->call([$this, $method]);\\n\",\"183\":\"        } finally {\\n\",\"184\":\"            if ($this instanceof Isolatable && $this->option(\'isolated\') !== false) {\\n\",\"185\":\"                $this->commandIsolationMutex()->forget($this);\\n\",\"186\":\"            }\\n\",\"187\":\"        }\\n\",\"188\":\"    }\\n\"},\"in_app\":false,\"arguments\":[]},{\"file\":\"\\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/symfony\\/console\\/Command\\/Command.php\",\"line\":326,\"function\":\"execute\",\"class\":\"Illuminate\\\\Console\\\\Command\",\"type\":\"->\",\"snippet\":{\"320\":\"        $input->validate();\\n\",\"321\":\"\\n\",\"322\":\"        if ($this->code) {\\n\",\"323\":\"            $statusCode = ($this->code)($input, $output);\\n\",\"324\":\"        } else {\\n\",\"325\":\"            $statusCode = $this->execute($input, $output);\\n\",\"326\":\"\\n\",\"327\":\"            if (!\\\\is_int($statusCode)) {\\n\",\"328\":\"                throw new \\\\TypeError(\\\\sprintf(\'Return value of \\\"%s::execute()\\\" must be of the type int, \\\"%s\\\" returned.\', static::class, get_debug_type($statusCode)));\\n\",\"329\":\"            }\\n\",\"330\":\"        }\\n\",\"331\":\"\\n\"},\"in_app\":false,\"arguments\":[]},{\"file\":\"\\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php\",\"line\":152,\"function\":\"run\",\"class\":\"Symfony\\\\Component\\\\Console\\\\Command\\\\Command\",\"type\":\"->\",\"snippet\":{\"146\":\"        );\\n\",\"147\":\"\\n\",\"148\":\"        $this->components = $this->laravel->make(Factory::class, [\'output\' => $this->output]);\\n\",\"149\":\"\\n\",\"150\":\"        try {\\n\",\"151\":\"            return parent::run(\\n\",\"152\":\"                $this->input = $input, $this->output\\n\",\"153\":\"            );\\n\",\"154\":\"        } finally {\\n\",\"155\":\"            $this->untrap();\\n\",\"156\":\"        }\\n\",\"157\":\"    }\\n\"},\"in_app\":false,\"arguments\":[]},{\"file\":\"\\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/symfony\\/console\\/Application.php\",\"line\":1078,\"function\":\"run\",\"class\":\"Illuminate\\\\Console\\\\Command\",\"type\":\"->\",\"snippet\":{\"1072\":\"                });\\n\",\"1073\":\"            }\\n\",\"1074\":\"        }\\n\",\"1075\":\"\\n\",\"1076\":\"        if (null === $this->dispatcher) {\\n\",\"1077\":\"            return $command->run($input, $output);\\n\",\"1078\":\"        }\\n\",\"1079\":\"\\n\",\"1080\":\"        \\/\\/ bind before the console.command event, so the listeners have access to input options\\/arguments\\n\",\"1081\":\"        try {\\n\",\"1082\":\"            $command->mergeApplicationDefinition();\\n\",\"1083\":\"            $input->bind($command->getDefinition());\\n\"},\"in_app\":false,\"arguments\":[]},{\"file\":\"\\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/symfony\\/console\\/Application.php\",\"line\":324,\"function\":\"doRunCommand\",\"class\":\"Symfony\\\\Component\\\\Console\\\\Application\",\"type\":\"->\",\"snippet\":{\"318\":\"        if ($command instanceof LazyCommand) {\\n\",\"319\":\"            $command = $command->getCommand();\\n\",\"320\":\"        }\\n\",\"321\":\"\\n\",\"322\":\"        $this->runningCommand = $command;\\n\",\"323\":\"        $exitCode = $this->doRunCommand($command, $input, $output);\\n\",\"324\":\"        $this->runningCommand = null;\\n\",\"325\":\"\\n\",\"326\":\"        return $exitCode;\\n\",\"327\":\"    }\\n\",\"328\":\"\\n\",\"329\":\"    \\/**\\n\"},\"in_app\":false,\"arguments\":[]},{\"file\":\"\\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/symfony\\/console\\/Application.php\",\"line\":175,\"function\":\"doRun\",\"class\":\"Symfony\\\\Component\\\\Console\\\\Application\",\"type\":\"->\",\"snippet\":{\"169\":\"        }\\n\",\"170\":\"\\n\",\"171\":\"        try {\\n\",\"172\":\"            $this->configureIO($input, $output);\\n\",\"173\":\"\\n\",\"174\":\"            $exitCode = $this->doRun($input, $output);\\n\",\"175\":\"        } catch (\\\\Throwable $e) {\\n\",\"176\":\"            if ($e instanceof \\\\Exception && !$this->catchExceptions) {\\n\",\"177\":\"                throw $e;\\n\",\"178\":\"            }\\n\",\"179\":\"            if (!$e instanceof \\\\Exception && !$this->catchErrors) {\\n\",\"180\":\"                throw $e;\\n\"},\"in_app\":false,\"arguments\":[]},{\"file\":\"\\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Application.php\",\"line\":102,\"function\":\"run\",\"class\":\"Symfony\\\\Component\\\\Console\\\\Application\",\"type\":\"->\",\"snippet\":{\"96\":\"            new CommandStarting(\\n\",\"97\":\"                $commandName, $input, $output = $output ?: new BufferedConsoleOutput\\n\",\"98\":\"            )\\n\",\"99\":\"        );\\n\",\"100\":\"\\n\",\"101\":\"        $exitCode = parent::run($input, $output);\\n\",\"102\":\"\\n\",\"103\":\"        $this->events->dispatch(\\n\",\"104\":\"            new CommandFinished($commandName, $input, $output, $exitCode)\\n\",\"105\":\"        );\\n\",\"106\":\"\\n\",\"107\":\"        return $exitCode;\\n\"},\"in_app\":false,\"arguments\":[]},{\"file\":\"\\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Console\\/Kernel.php\",\"line\":155,\"function\":\"run\",\"class\":\"Illuminate\\\\Console\\\\Application\",\"type\":\"->\",\"snippet\":{\"149\":\"                $this->bootstrapWithoutBootingProviders();\\n\",\"150\":\"            }\\n\",\"151\":\"\\n\",\"152\":\"            $this->bootstrap();\\n\",\"153\":\"\\n\",\"154\":\"            return $this->getArtisan()->run($input, $output);\\n\",\"155\":\"        } catch (Throwable $e) {\\n\",\"156\":\"            $this->reportException($e);\\n\",\"157\":\"\\n\",\"158\":\"            $this->renderException($output, $e);\\n\",\"159\":\"\\n\",\"160\":\"            return 1;\\n\"},\"in_app\":false,\"arguments\":[]},{\"file\":\"\\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/artisan\",\"line\":33,\"function\":\"handle\",\"class\":\"Illuminate\\\\Foundation\\\\Console\\\\Kernel\",\"type\":\"->\",\"snippet\":{\"27\":\"|\\n\",\"28\":\"*\\/\\n\",\"29\":\"\\n\",\"30\":\"$kernel = $app->make(Illuminate\\\\Contracts\\\\Console\\\\Kernel::class);\\n\",\"31\":\"\\n\",\"32\":\"$status = $kernel->handle(\\n\",\"33\":\"    $input = new Symfony\\\\Component\\\\Console\\\\Input\\\\ArgvInput,\\n\",\"34\":\"    new Symfony\\\\Component\\\\Console\\\\Output\\\\ConsoleOutput\\n\",\"35\":\");\\n\",\"36\":\"\\n\",\"37\":\"\\/*\\n\",\"38\":\"|--------------------------------------------------------------------------\\n\"},\"in_app\":false,\"arguments\":[]}],\"stringTrace\":\"#0 \\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(36): NumenCode\\\\SyncOps\\\\Console\\\\MediaPush->handle()\\n#1 \\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php(41): Illuminate\\\\Container\\\\BoundMethod::Illuminate\\\\Container\\\\{closure}()\\n#2 \\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(93): Illuminate\\\\Container\\\\Util::unwrapIfClosure()\\n#3 \\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(35): Illuminate\\\\Container\\\\BoundMethod::callBoundMethod()\\n#4 \\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php(661): Illuminate\\\\Container\\\\BoundMethod::call()\\n#5 \\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(183): Illuminate\\\\Container\\\\Container->call()\\n#6 \\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/symfony\\/console\\/Command\\/Command.php(326): Illuminate\\\\Console\\\\Command->execute()\\n#7 \\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(152): Symfony\\\\Component\\\\Console\\\\Command\\\\Command->run()\\n#8 \\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/symfony\\/console\\/Application.php(1078): Illuminate\\\\Console\\\\Command->run()\\n#9 \\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/symfony\\/console\\/Application.php(324): Symfony\\\\Component\\\\Console\\\\Application->doRunCommand()\\n#10 \\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/symfony\\/console\\/Application.php(175): Symfony\\\\Component\\\\Console\\\\Application->doRun()\\n#11 \\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Application.php(102): Symfony\\\\Component\\\\Console\\\\Application->run()\\n#12 \\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Console\\/Kernel.php(155): Illuminate\\\\Console\\\\Application->run()\\n#13 \\/home\\/webarea\\/web\\/webarea.eu\\/public_html\\/artisan(33): Illuminate\\\\Foundation\\\\Console\\\\Kernel->handle()\\n#14 {main}\",\"code\":0,\"previous\":null},\"environment\":{\"context\":\"CLI\",\"testing\":false,\"env\":\"development\"}}','2025-09-12 19:48:46','2025-09-12 19:48:46'),
(14,'info','No sitemap definition was found. Try creating one first.','[]','2025-09-13 02:40:55','2025-09-13 02:40:55');
/*!40000 ALTER TABLE `system_event_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `system_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `disk_name` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_size` int(11) NOT NULL,
  `content_type` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `field` varchar(255) DEFAULT NULL,
  `attachment_id` varchar(255) DEFAULT NULL,
  `attachment_type` varchar(255) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) DEFAULT NULL,
  `metadata` mediumtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_files_field_index` (`field`),
  KEY `system_files_attachment_id_index` (`attachment_id`),
  KEY `system_files_attachment_type_index` (`attachment_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `system_files` WRITE;
/*!40000 ALTER TABLE `system_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_files` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `system_mail_layouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_mail_layouts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `content_html` text DEFAULT NULL,
  `content_text` text DEFAULT NULL,
  `content_css` text DEFAULT NULL,
  `is_locked` tinyint(1) NOT NULL DEFAULT 0,
  `options` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `system_mail_layouts` WRITE;
/*!40000 ALTER TABLE `system_mail_layouts` DISABLE KEYS */;
REPLACE INTO `system_mail_layouts` VALUES
(1,'Default layout','default','<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\">\n<head>\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\n    <style type=\"text/css\" media=\"screen\">\n        {{ brandCss|raw }}\n        {{ css|raw }}\n    </style>\n</head>\n<body>\n    <table class=\"wrapper layout-default\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n\n        <!-- Header -->\n        {% partial \'header\' body %}\n            {{ subject|raw }}\n        {% endpartial %}\n\n        <tr>\n            <td align=\"center\">\n                <table class=\"content\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n                    <!-- Email Body -->\n                    <tr>\n                        <td class=\"body\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n                            <table class=\"inner-body\" align=\"center\" width=\"570\" cellpadding=\"0\" cellspacing=\"0\">\n                                <!-- Body content -->\n                                <tr>\n                                    <td class=\"content-cell\">\n                                        {{ content|raw }}\n                                    </td>\n                                </tr>\n                            </table>\n                        </td>\n                    </tr>\n                </table>\n            </td>\n        </tr>\n\n        <!-- Footer -->\n        {% partial \'footer\' body %}\n            &copy; {{ \"now\"|date(\"Y\") }} {{ appName }}. All rights reserved.\n        {% endpartial %}\n\n    </table>\n\n</body>\n</html>','{{ content|raw }}','@media only screen and (max-width: 600px) {\n    .inner-body {\n        width: 100% !important;\n    }\n\n    .footer {\n        width: 100% !important;\n    }\n}\n\n@media only screen and (max-width: 500px) {\n    .button {\n        width: 100% !important;\n    }\n}',1,NULL,'2025-02-13 11:01:21','2025-02-13 11:01:21'),
(2,'System layout','system','<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\">\n<head>\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\n    <style type=\"text/css\" media=\"screen\">\n        {{ brandCss|raw }}\n        {{ css|raw }}\n    </style>\n</head>\n<body>\n    <table class=\"wrapper layout-system\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n        <tr>\n            <td align=\"center\">\n                <table class=\"content\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n                    <!-- Email Body -->\n                    <tr>\n                        <td class=\"body\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n                            <table class=\"inner-body\" align=\"center\" width=\"570\" cellpadding=\"0\" cellspacing=\"0\">\n                                <!-- Body content -->\n                                <tr>\n                                    <td class=\"content-cell\">\n                                        {{ content|raw }}\n\n                                        <!-- Subcopy -->\n                                        {% partial \'subcopy\' body %}\n                                            **This is an automatic message. Please do not reply to it.**\n                                        {% endpartial %}\n                                    </td>\n                                </tr>\n                            </table>\n                        </td>\n                    </tr>\n                </table>\n            </td>\n        </tr>\n    </table>\n\n</body>\n</html>','{{ content|raw }}\n\n\n---\nThis is an automatic message. Please do not reply to it.','@media only screen and (max-width: 600px) {\n    .inner-body {\n        width: 100% !important;\n    }\n\n    .footer {\n        width: 100% !important;\n    }\n}\n\n@media only screen and (max-width: 500px) {\n    .button {\n        width: 100% !important;\n    }\n}',1,NULL,'2025-02-13 11:01:21','2025-02-13 11:01:21');
/*!40000 ALTER TABLE `system_mail_layouts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `system_mail_partials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_mail_partials` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `content_html` text DEFAULT NULL,
  `content_text` text DEFAULT NULL,
  `is_custom` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `system_mail_partials` WRITE;
/*!40000 ALTER TABLE `system_mail_partials` DISABLE KEYS */;
REPLACE INTO `system_mail_partials` VALUES
(1,'Header','header','<tr>\n    <td class=\"header\">\n        {% if url %}\n            <a href=\"{{ url }}\">\n                {{ body }}\n            </a>\n        {% else %}\n            <span>\n                {{ body }}\n            </span>\n        {% endif %}\n    </td>\n</tr>','*** {{ body|trim }} <{{ url }}>',0,'2025-02-21 11:19:08','2025-02-21 11:19:08'),
(2,'Footer','footer','<tr>\n    <td>\n        <table class=\"footer\" align=\"center\" width=\"570\" cellpadding=\"0\" cellspacing=\"0\">\n            <tr>\n                <td class=\"content-cell\" align=\"center\">\n                    {{ body|md_safe }}\n                </td>\n            </tr>\n        </table>\n    </td>\n</tr>','-------------------\n{{ body|trim }}',0,'2025-02-21 11:19:08','2025-02-21 11:19:08'),
(3,'Button','button','<table class=\"action\" align=\"center\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n    <tr>\n        <td align=\"center\">\n            <table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n                <tr>\n                    <td align=\"center\">\n                        <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n                            <tr>\n                                <td>\n                                    <a href=\"{{ url }}\" class=\"button button-{{ type ?: \'primary\' }}\" target=\"_blank\">{{ body }}</a>\n                                </td>\n                            </tr>\n                        </table>\n                    </td>\n                </tr>\n            </table>\n        </td>\n    </tr>\n</table>','{{ body|trim }} <{{ url }}>',0,'2025-02-21 11:19:09','2025-02-21 11:19:09'),
(4,'Panel','panel','<table class=\"panel break-all\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n    <tr>\n        <td class=\"panel-content\">\n            <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n                <tr>\n                    <td class=\"panel-item\">\n                        {{ body|md_safe }}\n                    </td>\n                </tr>\n            </table>\n        </td>\n    </tr>\n</table>','{{ body|trim }}',0,'2025-02-21 11:19:09','2025-02-21 11:19:09'),
(5,'Table','table','<div class=\"table\">\n    {{ body|md_safe }}\n</div>','{{ body|trim }}',0,'2025-02-21 11:19:09','2025-02-21 11:19:09'),
(6,'Subcopy','subcopy','<table class=\"subcopy\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n    <tr>\n        <td>\n            {{ body|md_safe }}\n        </td>\n    </tr>\n</table>','-----\n{{ body|trim }}',0,'2025-02-21 11:19:09','2025-02-21 11:19:09'),
(7,'Promotion','promotion','<table class=\"promotion break-all\" align=\"center\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n    <tr>\n        <td align=\"center\">\n            {{ body|md_safe }}\n        </td>\n    </tr>\n</table>','{{ body|trim }}',0,'2025-02-21 11:19:09','2025-02-21 11:19:09');
/*!40000 ALTER TABLE `system_mail_partials` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `system_mail_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_mail_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `content_html` text DEFAULT NULL,
  `content_text` text DEFAULT NULL,
  `layout_id` int(11) DEFAULT NULL,
  `is_custom` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_mail_templates_layout_id_index` (`layout_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `system_mail_templates` WRITE;
/*!40000 ALTER TABLE `system_mail_templates` DISABLE KEYS */;
REPLACE INTO `system_mail_templates` VALUES
(1,'backend::mail.invite',NULL,'Invite new admin to the site',NULL,NULL,2,0,'2025-02-21 11:19:09','2025-02-21 11:19:09'),
(2,'backend::mail.restore',NULL,'Reset an admin password',NULL,NULL,2,0,'2025-02-21 11:19:09','2025-02-21 11:19:09');
/*!40000 ALTER TABLE `system_mail_templates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `system_parameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_parameters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `namespace` varchar(100) NOT NULL,
  `group` varchar(50) NOT NULL,
  `item` varchar(150) NOT NULL,
  `value` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item_index` (`namespace`,`group`,`item`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `system_parameters` WRITE;
/*!40000 ALTER TABLE `system_parameters` DISABLE KEYS */;
REPLACE INTO `system_parameters` VALUES
(1,'system','app','birthday','\"2025-02-13T12:01:20.695174Z\"'),
(2,'system','update','count','0'),
(3,'system','update','retry','1758218466'),
(4,'system','core','build','\"1.2.8\"'),
(5,'system','core','modified','0');
/*!40000 ALTER TABLE `system_parameters` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `system_plugin_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_plugin_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `type` varchar(20) NOT NULL,
  `version` varchar(50) NOT NULL,
  `detail` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_plugin_history_code_index` (`code`),
  KEY `system_plugin_history_type_index` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=257 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `system_plugin_history` WRITE;
/*!40000 ALTER TABLE `system_plugin_history` DISABLE KEYS */;
REPLACE INTO `system_plugin_history` VALUES
(1,'Winter.Demo','comment','1.0.1','First version of Demo','2025-02-13 11:01:21'),
(2,'Winter.Cloudflare','comment','1.0.1','First version of Cloudflare','2025-02-18 15:34:07'),
(3,'Winter.Cloudflare','comment','1.0.2','Updated Cloudflare\'s IP range','2025-02-18 15:34:07'),
(4,'Winter.Cloudflare','comment','1.0.3','Disabled Rocket Loader for javascript assets in the backend as it would cause them to break. Requires Build 460.','2025-02-18 15:34:07'),
(5,'Winter.Cloudflare','comment','2.0.0','Renamed to Winter.Cloudflare','2025-02-18 15:34:07'),
(6,'Winter.Cloudflare','comment','2.0.1','Fixed missing import in Plugin.php','2025-02-18 15:34:07'),
(7,'NumenCode.DropboxAdapter','comment','1.0.1','Initialize plugin','2025-08-02 11:05:50'),
(8,'NumenCode.Fundamentals','comment','1.0.1','Initialize plugin.','2025-08-02 11:05:50'),
(9,'NumenCode.Widgets','comment','1.0.1','Initialize plugin','2025-08-02 11:05:50'),
(10,'NumenCode.Widgets','script','1.0.2','create_numencode_widgets_promotions_groups_table.php','2025-08-02 11:05:50'),
(11,'NumenCode.Widgets','comment','1.0.2','Created table numencode_widgets_promotions_groups','2025-08-02 11:05:50'),
(12,'NumenCode.Widgets','script','1.0.3','create_numencode_widgets_promotions_items_table.php','2025-08-02 11:05:50'),
(13,'NumenCode.Widgets','comment','1.0.3','Created table numencode_widgets_promotions_items','2025-08-02 11:05:50'),
(14,'NumenCode.Widgets','script','1.0.4','create_numencode_widgets_highlights_groups_table.php','2025-08-02 11:05:50'),
(15,'NumenCode.Widgets','comment','1.0.4','Created table numencode_widgets_highlights_groups','2025-08-02 11:05:50'),
(16,'NumenCode.Widgets','script','1.0.5','create_numencode_widgets_highlights_items_table.php','2025-08-02 11:05:50'),
(17,'NumenCode.Widgets','comment','1.0.5','Created table numencode_widgets_highlights_items','2025-08-02 11:05:50'),
(18,'NumenCode.Widgets','script','1.0.6','create_numencode_widgets_features_groups_table.php','2025-08-02 11:05:50'),
(19,'NumenCode.Widgets','comment','1.0.6','Created table numencode_widgets_features_groups','2025-08-02 11:05:50'),
(20,'NumenCode.Widgets','script','1.0.7','create_numencode_widgets_features_items_table.php','2025-08-02 11:05:50'),
(21,'NumenCode.Widgets','comment','1.0.7','Created table numencode_widgets_features_items','2025-08-02 11:05:50'),
(22,'NumenCode.Widgets','script','1.0.8','create_numencode_widgets_gallery_groups_table.php','2025-08-02 11:05:50'),
(23,'NumenCode.Widgets','comment','1.0.8','Created table numencode_widgets_gallery_groups','2025-08-02 11:05:50'),
(24,'NumenCode.Widgets','script','1.0.9','create_numencode_widgets_gallery_items_table.php','2025-08-02 11:05:50'),
(25,'NumenCode.Widgets','comment','1.0.9','Created table numencode_widgets_gallery_items','2025-08-02 11:05:50'),
(26,'Winter.Builder','comment','1.0.1','Initialize plugin.','2025-08-02 11:05:50'),
(27,'Winter.Builder','comment','1.0.2','Fixes the problem with selecting a plugin. Minor localization corrections. Configuration files in the list and form behaviors are now autocomplete.','2025-08-02 11:05:50'),
(28,'Winter.Builder','comment','1.0.3','Improved handling of the enum data type.','2025-08-02 11:05:50'),
(29,'Winter.Builder','comment','1.0.4','Added user permissions to work with the Builder.','2025-08-02 11:05:50'),
(30,'Winter.Builder','comment','1.0.5','Fixed permissions registration.','2025-08-02 11:05:50'),
(31,'Winter.Builder','comment','1.0.6','Fixed front-end record ordering in the Record List component.','2025-08-02 11:05:50'),
(32,'Winter.Builder','comment','1.0.7','Builder settings are now protected with user permissions. The database table column list is scrollable now. Minor code cleanup.','2025-08-02 11:05:50'),
(33,'Winter.Builder','comment','1.0.8','Added the Reorder Controller behavior.','2025-08-02 11:05:50'),
(34,'Winter.Builder','comment','1.0.9','Minor API and UI updates.','2025-08-02 11:05:50'),
(35,'Winter.Builder','comment','1.0.10','Minor styling update.','2025-08-02 11:05:50'),
(36,'Winter.Builder','comment','1.0.11','Fixed a bug where clicking placeholder in a repeater would open Inspector. Fixed a problem with saving forms with repeaters in tabs. Minor style fix.','2025-08-02 11:05:50'),
(37,'Winter.Builder','comment','1.0.12','Added support for the Trigger property to the Media Finder widget configuration. Names of form fields and list columns definition files can now contain underscores.','2025-08-02 11:05:50'),
(38,'Winter.Builder','comment','1.0.13','Minor styling fix on the database editor.','2025-08-02 11:05:50'),
(39,'Winter.Builder','comment','1.0.14','Added support for published_at timestamp field','2025-08-02 11:05:50'),
(40,'Winter.Builder','comment','1.0.15','Fixed a bug where saving a localization string in Inspector could cause a JavaScript error. Added support for Timestamps and Soft Deleting for new models.','2025-08-02 11:05:50'),
(41,'Winter.Builder','comment','1.0.16','Fixed a bug when saving a form with the Repeater widget in a tab could create invalid fields in the form\'s outside area. Added a check that prevents creating localization strings inside other existing strings.','2025-08-02 11:05:50'),
(42,'Winter.Builder','comment','1.0.17','Added support Trigger attribute support for RecordFinder and Repeater form widgets.','2025-08-02 11:05:50'),
(43,'Winter.Builder','comment','1.0.18','Fixes a bug where \'::class\' notations in a model class definition could prevent the model from appearing in the Builder model list. Added emptyOption property support to the dropdown form control.','2025-08-02 11:05:50'),
(44,'Winter.Builder','comment','1.0.19','Added a feature allowing to add all database columns to a list definition. Added max length validation for database table and column names.','2025-08-02 11:05:50'),
(45,'Winter.Builder','comment','1.0.20','Fixes a bug where form the builder could trigger the \"current.hasAttribute is not a function\" error.','2025-08-02 11:05:50'),
(46,'Winter.Builder','comment','1.0.21','Back-end navigation sort order updated.','2025-08-02 11:05:50'),
(47,'Winter.Builder','comment','1.0.22','Added scopeValue property to the RecordList component.','2025-08-02 11:05:50'),
(48,'Winter.Builder','comment','1.0.23','Added support for balloon-selector field type, added Brazilian Portuguese translation, fixed some bugs','2025-08-02 11:05:50'),
(49,'Winter.Builder','comment','1.0.24','Added support for tag list field type, added read only toggle for fields. Prevent plugins from using reserved PHP keywords for class names and namespaces','2025-08-02 11:05:50'),
(50,'Winter.Builder','comment','1.0.25','Allow editing of migration code in the \"Migration\" popup when saving changes in the database editor.','2025-08-02 11:05:50'),
(51,'Winter.Builder','comment','1.0.26','Allow special default values for columns and added new \"Add ID column\" button to database editor.','2025-08-02 11:05:50'),
(52,'Winter.Builder','comment','1.0.27','Added ability to use \'scope\' in a form relation field, added ability to change the sort order of versions and added additional properties for repeater widget in form builder. Added Polish translation.','2025-08-02 11:05:50'),
(53,'Winter.Builder','script','2.0.0','v2.0.0/convert_data.php','2025-08-02 11:05:50'),
(54,'Winter.Builder','comment','2.0.0','Rebrand to Winter.Builder','2025-08-02 11:05:50'),
(55,'Winter.Builder','comment','2.0.0','Fixes namespace parsing on php >= 8.0','2025-08-02 11:05:50'),
(56,'Winter.Builder','comment','2.0.1','Fixed missing icons in icon selection, rebranded icons to Winter.','2025-08-02 11:05:50'),
(57,'Winter.Builder','comment','2.0.2','Added fields to control plugin replacement, PHP8 compatibility fixes.','2025-08-02 11:05:50'),
(58,'Winter.Builder','comment','2.0.3','Added support for image columns','2025-08-02 11:05:50'),
(59,'Winter.Builder','comment','2.0.4','Added ability to modify Plugin replacement options. Automatically populate the model\'s `$jsonable` property for field types that require it. UX improvements.','2025-08-02 11:05:50'),
(60,'Winter.Builder','comment','2.0.5','Fix issue with table selection when creating a model.','2025-08-02 11:05:50'),
(61,'Winter.Builder','comment','2.0.6','Fix issues with JSON-able models, fix search functionality, fix automated tests.','2025-08-02 11:05:50'),
(62,'Winter.Builder','comment','2.1.0','spaceless tag replaced with apply filter by @arvislacis in #55','2025-08-02 11:05:50'),
(63,'Winter.Builder','comment','2.1.0','Added labels options for the on/off switch state for the switch control widget by @webbati in #56','2025-08-02 11:05:50'),
(64,'Winter.Builder','comment','2.1.0','The plugin icon is now using the Icon Picker widget to easily browse and select an icon.','2025-08-02 11:05:50'),
(65,'Winter.Builder','comment','2.1.0','PhpFileParser has been renamed to PhpSourceParser and supports loading and parsing files, or parsing code directly.','2025-08-02 11:05:50'),
(66,'Winter.Builder','comment','2.1.0','Migrations are now validated to ensure that they are valid migration or seeder classes (ie. they must extend the Winter\\Storm\\Database\\Updates\\Migration or Winter\\Storm\\Database\\Updates\\Seeder classes.','2025-08-02 11:05:50'),
(67,'Winter.Builder','comment','2.1.0','The migration and seeder templates have been updated to fit Winter\'s core coding style.','2025-08-02 11:05:50'),
(68,'Winter.Builder','comment','2.1.0','Anonymous migration classes are now fully supported.','2025-08-02 11:05:50'),
(69,'Winter.Builder','comment','2.1.0','Duplicate migration file name assignment has been improved and there should now be less (or no) conflicts.','2025-08-02 11:05:50'),
(70,'Winter.Builder','comment','2.1.0','Fixed an issue where migration files stored within subdirectories could not be read or saved.','2025-08-02 11:05:50'),
(71,'Winter.Builder','comment','2.1.0','The permissions data table is now scrollable and will stretch to full height.','2025-08-02 11:05:50'),
(72,'Winter.Builder','comment','2.1.1','Fix issue when creating new plugins','2025-08-02 11:05:50'),
(73,'Winter.Pages','comment','1.0.1','Implemented the static pages management and the Static Page component.','2025-08-02 11:05:50'),
(74,'Winter.Pages','comment','1.0.2','Fixed the page preview URL.','2025-08-02 11:05:50'),
(75,'Winter.Pages','comment','1.0.3','Implemented menus.','2025-08-02 11:05:50'),
(76,'Winter.Pages','comment','1.0.4','Implemented the content block management and placeholder support.','2025-08-02 11:05:50'),
(77,'Winter.Pages','comment','1.0.5','Added support for the Sitemap plugin.','2025-08-02 11:05:50'),
(78,'Winter.Pages','comment','1.0.6','Minor updates to the internal API.','2025-08-02 11:05:50'),
(79,'Winter.Pages','comment','1.0.7','Added the Snippets feature.','2025-08-02 11:05:50'),
(80,'Winter.Pages','comment','1.0.8','Minor improvements to the code.','2025-08-02 11:05:50'),
(81,'Winter.Pages','comment','1.0.9','Fixes issue where Snippet tab is missing from the Partials form.','2025-08-02 11:05:50'),
(82,'Winter.Pages','comment','1.0.10','Add translations for various locales.','2025-08-02 11:05:50'),
(83,'Winter.Pages','comment','1.0.11','Fixes issue where placeholders tabs were missing from Page form.','2025-08-02 11:05:50'),
(84,'Winter.Pages','comment','1.0.12','Implement Media Manager support.','2025-08-02 11:05:50'),
(85,'Winter.Pages','script','1.1.0','v1.1.0/snippets_rename_viewbag_properties.php','2025-08-02 11:05:50'),
(86,'Winter.Pages','comment','1.1.0','Adds meta title and description to pages. Adds |staticPage filter.','2025-08-02 11:05:50'),
(87,'Winter.Pages','comment','1.1.1','Add support for Syntax Fields.','2025-08-02 11:05:50'),
(88,'Winter.Pages','comment','1.1.2','Static Breadcrumbs component now respects the hide from navigation setting.','2025-08-02 11:05:50'),
(89,'Winter.Pages','comment','1.1.3','Minor back-end styling fix.','2025-08-02 11:05:50'),
(90,'Winter.Pages','comment','1.1.4','Minor fix to the StaticPage component API.','2025-08-02 11:05:51'),
(91,'Winter.Pages','comment','1.1.5','Fixes bug when using syntax fields.','2025-08-02 11:05:51'),
(92,'Winter.Pages','comment','1.1.6','Minor styling fix to the back-end UI.','2025-08-02 11:05:51'),
(93,'Winter.Pages','comment','1.1.7','Improved menu item form to include CSS class, open in a new window and hidden flag.','2025-08-02 11:05:51'),
(94,'Winter.Pages','comment','1.1.8','Improved the output of snippet partials when saved.','2025-08-02 11:05:51'),
(95,'Winter.Pages','comment','1.1.9','Minor update to snippet inspector internal API.','2025-08-02 11:05:51'),
(96,'Winter.Pages','comment','1.1.10','Fixes a bug where selecting a layout causes permanent unsaved changes.','2025-08-02 11:05:51'),
(97,'Winter.Pages','comment','1.1.11','Add support for repeater syntax field.','2025-08-02 11:05:51'),
(98,'Winter.Pages','comment','1.2.0','Added support for translations, UI updates.','2025-08-02 11:05:51'),
(99,'Winter.Pages','comment','1.2.1','Use nice titles when listing the content files.','2025-08-02 11:05:51'),
(100,'Winter.Pages','comment','1.2.2','Minor styling update.','2025-08-02 11:05:51'),
(101,'Winter.Pages','comment','1.2.3','Snippets can now be moved by dragging them.','2025-08-02 11:05:51'),
(102,'Winter.Pages','comment','1.2.4','Fixes a bug where the cursor is misplaced when editing text files.','2025-08-02 11:05:51'),
(103,'Winter.Pages','comment','1.2.5','Fixes a bug where the parent page is lost upon changing a page layout.','2025-08-02 11:05:51'),
(104,'Winter.Pages','comment','1.2.6','Shared view variables are now passed to static pages.','2025-08-02 11:05:51'),
(105,'Winter.Pages','comment','1.2.7','Fixes issue with duplicating properties when adding multiple snippets on the same page.','2025-08-02 11:05:51'),
(106,'Winter.Pages','comment','1.2.8','Fixes a bug where creating a content block without extension doesn\'t save the contents to file.','2025-08-02 11:05:51'),
(107,'Winter.Pages','comment','1.2.9','Add conditional support for translating page URLs.','2025-08-02 11:05:51'),
(108,'Winter.Pages','comment','1.2.10','Streamline generation of URLs to use the new Cms::url helper.','2025-08-02 11:05:51'),
(109,'Winter.Pages','comment','1.2.11','Implements repeater usage with translate plugin.','2025-08-02 11:05:51'),
(110,'Winter.Pages','comment','1.2.12','Fixes minor issue when using snippets and switching the application locale.','2025-08-02 11:05:51'),
(111,'Winter.Pages','comment','1.2.13','Fixes bug when AJAX is used on a page that does not yet exist.','2025-08-02 11:05:51'),
(112,'Winter.Pages','comment','1.2.14','Add theme logging support for changes made to menus.','2025-08-02 11:05:51'),
(113,'Winter.Pages','comment','1.2.15','Back-end navigation sort order updated.','2025-08-02 11:05:51'),
(114,'Winter.Pages','comment','1.2.16','Fixes a bug when saving a template that has been modified outside of the CMS (mtime mismatch).','2025-08-02 11:05:51'),
(115,'Winter.Pages','comment','1.2.17','Changes locations of custom fields to secondary tabs instead of the primary Settings area. New menu search ability on adding menu items','2025-08-02 11:05:51'),
(116,'Winter.Pages','comment','1.2.18','Fixes cache-invalidation issues when Winter.Translate is not installed. Added Greek & Simplified Chinese translations. Removed deprecated calls. Allowed saving HTML in snippet properties. Added support for the MediaFinder in menu items.','2025-08-02 11:05:51'),
(117,'Winter.Pages','comment','1.2.19','Catch exception with corrupted menu file.','2025-08-02 11:05:51'),
(118,'Winter.Pages','comment','1.2.20','StaticMenu component now exposes menuName property; added pages.menu.referencesGenerated event.','2025-08-02 11:05:51'),
(119,'Winter.Pages','comment','1.2.21','Fixes a bug where last Static Menu item cannot be deleted. Improved Persian, Slovak and Turkish translations.','2025-08-02 11:05:51'),
(120,'Winter.Pages','comment','1.3.0','Added support for using Database-driven Themes when enabled in the CMS configuration.','2025-08-02 11:05:51'),
(121,'Winter.Pages','comment','1.3.1','Added ChildPages Component, prevent hidden pages from being returned via menu item resolver.','2025-08-02 11:05:51'),
(122,'Winter.Pages','comment','1.3.2','Fixes error when creating a subpage whose parent has no layout set.','2025-08-02 11:05:51'),
(123,'Winter.Pages','comment','1.3.3','Improves user experience for users with only partial access through permissions','2025-08-02 11:05:51'),
(124,'Winter.Pages','comment','1.3.4','Fix error where large menus were being truncated due to the PHP \"max_input_vars\" configuration value. Improved Slovenian translation.','2025-08-02 11:05:51'),
(125,'Winter.Pages','comment','1.3.5','Minor fix to bust the browser cache for JS assets. Prevent duplicate property fields in snippet inspector.','2025-08-02 11:05:51'),
(126,'Winter.Pages','comment','1.3.6','ChildPages component now displays localized page titles from Translate plugin.','2025-08-02 11:05:51'),
(127,'Winter.Pages','comment','1.3.7','Improved page loading performance, added MenuPicker formwidget, added pages.snippets.listSnippets','2025-08-02 11:05:51'),
(128,'Winter.Pages','comment','1.4.0','Fixes bug when adding menu items in October CMS v2.0.','2025-08-02 11:05:51'),
(129,'Winter.Pages','comment','1.4.1','Fixes support for configuration values.','2025-08-02 11:05:51'),
(130,'Winter.Pages','comment','1.4.3','Fixes page deletion in newer platform builds.','2025-08-02 11:05:51'),
(131,'Winter.Pages','comment','2.0.0','Rebrand to Winter.Pages','2025-08-02 11:05:51'),
(132,'Winter.Pages','comment','2.0.1','Fixes rich editor usage inside repeaters.','2025-08-02 11:05:51'),
(133,'Winter.Pages','comment','2.0.1','Fixes a lifecycle issue when switching the page layout.','2025-08-02 11:05:51'),
(134,'Winter.Pages','comment','2.0.1','Fixes maintenance mode when using static pages.','2025-08-02 11:05:51'),
(135,'Winter.Pages','comment','2.0.2','Add support for Winter 1.2','2025-08-02 11:05:51'),
(136,'Winter.Pages','comment','2.0.3','Fixed issue with Primary Tabs losing min-size class','2025-08-02 11:05:51'),
(137,'Winter.Pages','comment','2.0.3','Added Vietnamese translation','2025-08-02 11:05:51'),
(138,'Winter.Pages','comment','2.0.3','Fixed issue where subpages of home would get 2 slashes','2025-08-02 11:05:51'),
(139,'Winter.Pages','comment','2.0.3','Fixed issue where allowed IPs couldn\'t access pages in maintenance mode','2025-08-02 11:05:51'),
(140,'Winter.Pages','comment','2.0.3','Improved Swedish translation','2025-08-02 11:05:51'),
(141,'Winter.Pages','comment','2.1.0','Added support for live previews of the frontend-rendered pages','2025-08-02 11:05:51'),
(142,'Winter.Pages','comment','2.1.1','Improved French translation','2025-08-02 11:05:51'),
(143,'Winter.Pages','comment','2.1.2','Added support for multilingual sitemap URLs','2025-08-02 11:05:51'),
(144,'Winter.Pages','comment','2.1.2','Fixed support for Winter.Translate','2025-08-02 11:05:51'),
(145,'Winter.Pages','comment','2.1.2','Collapse all pages in the backend list of pages by default','2025-08-02 11:05:51'),
(146,'Winter.Pages','comment','2.1.3','Added Duplicate button','2025-08-02 11:05:51'),
(147,'Winter.Pages','comment','2.1.4','Fix support for snippets in the default backend skin','2025-08-02 11:05:51'),
(148,'Winter.Pages','comment','2.1.5','Fixes issue where translated page content was not duplicated when duplicating a page','2025-08-02 11:05:51'),
(149,'Winter.Pages','comment','2.1.5','Fixes issue where the modified page counter was not working when updating a duplicated page','2025-08-02 11:05:51'),
(150,'Winter.Pages','comment','2.1.5','Made the MenuItems FormWidget more flexible','2025-08-02 11:05:51'),
(151,'Winter.Pages','comment','2.1.5','Apply Winter Coding Standards','2025-08-02 11:05:51'),
(152,'Winter.Pages','comment','2.1.5','Fixed issue caused by saving content before closing open snippet inspectors','2025-08-02 11:05:51'),
(153,'Winter.Pages','comment','2.1.5','Improved support for snippets defined in partials','2025-08-02 11:05:51'),
(154,'Winter.Pages','comment','2.2.0','Winter CMS v1.2.7+ is now required','2025-08-02 11:05:51'),
(155,'Winter.Redirect','script','1.0.0','20180718_0001_create_tables.php','2025-08-02 11:05:51'),
(156,'Winter.Redirect','script','1.0.0','20180831_0002_upgrade_from_adrenth_redirect.php','2025-08-02 11:05:51'),
(157,'Winter.Redirect','comment','1.0.0','Transfer vendor ownership. Adrenth.Redirect -> Vdlp.Redirect','2025-08-02 11:05:51'),
(158,'Winter.Redirect','comment','1.1.0','Redirect rules are now being cached (if caching enabled) -- See: https://github.com/vdlp/oc-redirect-plugin/issues/1','2025-08-02 11:05:51'),
(159,'Winter.Redirect','comment','1.2.0','Add extra filters to the Redirects overview -- See: https://github.com/vdlp/oc-redirect-plugin/pull/5','2025-08-02 11:05:51'),
(160,'Winter.Redirect','script','1.3.0','20181019_0003_add_ignore_query_parameters_to_redirects_table.php','2025-08-02 11:05:51'),
(161,'Winter.Redirect','comment','1.3.0','Add support for ignoring query parameters -- See: https://github.com/vdlp/oc-redirect-plugin/issues/6','2025-08-02 11:05:51'),
(162,'Winter.Redirect','comment','1.4.0','Code dusting and improvements to the redirect list view','2025-08-02 11:05:51'),
(163,'Winter.Redirect','script','1.4.1','20181117_0004_add_redirect_timestamp_crawler_index_on_clients_table.php','2025-08-02 11:05:51'),
(164,'Winter.Redirect','comment','1.4.1','Add extra statistics database index to improve performance','2025-08-02 11:05:51'),
(165,'Winter.Redirect','script','1.4.2','20181117_0005_add_month_year_crawler_index_on_clients_table.php','2025-08-02 11:05:51'),
(166,'Winter.Redirect','comment','1.4.2','Add extra statistics database index to improve performance (Statistics dashboard)','2025-08-02 11:05:51'),
(167,'Winter.Redirect','comment','1.4.3','Fix thrown BindingResolutionException on redirecting','2025-08-02 11:05:51'),
(168,'Winter.Redirect','comment','1.4.4','Fixes a redirect loop bug which might occur after renaming content pages','2025-08-02 11:05:51'),
(169,'Winter.Redirect','comment','1.4.5','Fixes critical issue with ignoring query parameters','2025-08-02 11:05:51'),
(170,'Winter.Redirect','comment','1.5.0','Bugfixes and added more extensibility support -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/1.5.0','2025-08-02 11:05:51'),
(171,'Winter.Redirect','script','1.6.0','20190404_0006_add_description_to_redirects_table.php','2025-08-02 11:05:51'),
(172,'Winter.Redirect','comment','1.6.0','Minor UI additions and added new Match Type: Regular Expressions! -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/1.6.0','2025-08-02 11:05:51'),
(173,'Winter.Redirect','comment','1.7.0','Bugfixes and code improvements -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/1.7.0','2025-08-02 11:05:51'),
(174,'Winter.Redirect','comment','1.8.0','Add CLI command for publishing redirects -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/1.8.0','2025-08-02 11:05:51'),
(175,'Winter.Redirect','comment','1.8.1','Fix critical issue regarding regular expression redirects','2025-08-02 11:05:51'),
(176,'Winter.Redirect','comment','1.9.0','Add setting for enabling/disabling automatic creation of redirects -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/1.9.0','2025-08-02 11:05:51'),
(177,'Winter.Redirect','script','1.10.0','20190704_0007_add_timestamp_crawler_index_on_clients_table.php','2025-08-02 11:05:51'),
(178,'Winter.Redirect','comment','1.10.0','Improve statistics performance -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/1.10.0','2025-08-02 11:05:51'),
(179,'Winter.Redirect','comment','1.10.1','This fixes an issue where redirects will fail to work when the redirects.csv file does not have the write permission -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/1.10.1','2025-08-02 11:05:51'),
(180,'Winter.Redirect','comment','1.10.2','Fixes a fatal error when running TestLab -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/1.10.2','2025-08-02 11:05:51'),
(181,'Winter.Redirect','comment','1.10.3','Fix support for Postgres -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/1.10.3','2025-08-02 11:05:51'),
(182,'Winter.Redirect','comment','1.10.4','Fixes reported issues #41 and #43 -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/1.10.4','2025-08-02 11:05:51'),
(183,'Winter.Redirect','comment','1.10.5','Fixes reported issues #46 and #49 -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/1.10.5','2025-08-02 11:05:51'),
(184,'Winter.Redirect','comment','2.0.0','Supports PHP 7.1.3 and higher. Read CHANGELOG.md -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/2.0.0','2025-08-02 11:05:51'),
(185,'Winter.Redirect','comment','2.0.1','Fix Middleware not being invoked in newer PHP versions -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/2.0.1','2025-08-02 11:05:51'),
(186,'Winter.Redirect','script','2.0.2','20200408_0008_change_column_types_from_char_to_varchar.php','2025-08-02 11:05:52'),
(187,'Winter.Redirect','comment','2.0.2','Minor database and configuration fixes -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/2.0.2','2025-08-02 11:05:52'),
(188,'Winter.Redirect','comment','2.1.0','Added support for October CMS L6 build, improved caching and more -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/2.1.0','2025-08-02 11:05:52'),
(189,'Winter.Redirect','comment','2.1.1','Update CHANGELOG','2025-08-02 11:05:52'),
(190,'Winter.Redirect','comment','2.2.0','Add cache control header and UI improvements -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/2.2.0','2025-08-02 11:05:52'),
(191,'Winter.Redirect','script','2.3.0','20200414_0009_add_ignore_case_to_redirects_table.php','2025-08-02 11:05:52'),
(192,'Winter.Redirect','script','2.3.0','20200414_0010_add_ignore_trailing_slash_to_redirects_table.php','2025-08-02 11:05:52'),
(193,'Winter.Redirect','comment','2.3.0','Add new redirect options (ignore case and ignore trailing slash) -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/2.3.0','2025-08-02 11:05:52'),
(194,'Winter.Redirect','comment','2.3.1','Fix SQLSTATE[42S22] error when installing plugin -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/2.3.1','2025-08-02 11:05:52'),
(195,'Winter.Redirect','comment','2.3.2','Improve error handling in plugin migration process -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/2.3.2','2025-08-02 11:05:52'),
(196,'Winter.Redirect','comment','2.4.0','Skip requests with header \'X-Requested-With: XMLHttpRequest\' -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/2.4.0','2025-08-02 11:05:52'),
(197,'Winter.Redirect','comment','2.4.1','Add Redirect Extensions promo page -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/2.4.1','2025-08-02 11:05:52'),
(198,'Winter.Redirect','comment','2.5.0','Add support for using relative paths -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/2.5.0','2025-08-02 11:05:52'),
(199,'Winter.Redirect','comment','2.5.1','Fixes issues with redirect rules file not being present -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/2.5.1','2025-08-02 11:05:52'),
(200,'Winter.Redirect','comment','2.5.2','Fix bug that causes re-writing the redirect rules file when hits are updated -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/2.5.2','2025-08-02 11:05:52'),
(201,'Winter.Redirect','comment','2.5.3','Improve / fixes redirect rule caching -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/2.5.3','2025-08-02 11:05:52'),
(202,'Winter.Redirect','comment','2.5.4','Add support for symfony/stopwatch:^5.0 (version 4.0 is still supported) -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/2.5.4','2025-08-02 11:05:52'),
(203,'Winter.Redirect','comment','2.5.5','Suppress logging when redirect rules file is empty -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/2.5.5','2025-08-02 11:05:52'),
(204,'Winter.Redirect','comment','2.5.6','Prevent connection exception when accessing settings in CLI mode -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/2.5.6','2025-08-02 11:05:52'),
(205,'Winter.Redirect','comment','2.5.7','Improve redirect caching management -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/2.5.7','2025-08-02 11:05:52'),
(206,'Winter.Redirect','comment','2.5.8','Improve redirect caching management (revised) -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/2.5.8','2025-08-02 11:05:52'),
(207,'Winter.Redirect','comment','2.5.9','Fix import in Plugin file','2025-08-02 11:05:52'),
(208,'Winter.Redirect','comment','2.5.10','Add PHP 8.0 version constraint and composer/installers package','2025-08-02 11:05:52'),
(209,'Winter.Redirect','comment','2.5.11','Minor fixes -- See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/2.5.11','2025-08-02 11:05:52'),
(210,'Winter.Redirect','comment','2.5.12','Fix strpos() type error','2025-08-02 11:05:52'),
(211,'Winter.Redirect','comment','2.5.13','Fix database error when cache is being cleared before installation of plugin.','2025-08-02 11:05:52'),
(212,'Winter.Redirect','comment','2.6.0','Update plugin dependencies.','2025-08-02 11:05:52'),
(213,'Winter.Redirect','script','3.0.0','20200918_0011_refactor_redirects_logs_table.php','2025-08-02 11:05:52'),
(214,'Winter.Redirect','script','3.0.0','20200918_0012_add_redirect_id_to_system_request_logs_table.php','2025-08-02 11:05:52'),
(215,'Winter.Redirect','comment','3.0.0','Drop support for October CMS 1.1 and lower. See: https://github.com/vdlp/oc-redirect-plugin/releases/tag/3.0.0','2025-08-02 11:05:52'),
(216,'Winter.Redirect','comment','3.0.1','Add support for regular expression matches in target path.','2025-08-02 11:05:52'),
(217,'Winter.Redirect','comment','3.0.2','Change version constraint for composer/installers.','2025-08-02 11:05:52'),
(218,'Winter.Redirect','comment','3.0.3','Update plugin dependencies','2025-08-02 11:05:52'),
(219,'Winter.Redirect','script','4.0.1','20220415_0013_rename_to_winter_redirect.php','2025-08-02 11:05:52'),
(220,'Winter.Redirect','comment','4.0.1','Renamed to Winter.Redirect, forked for use as a Winter CMS plugin.','2025-08-02 11:05:52'),
(221,'Winter.Redirect','comment','4.0.2','Maintained compatibility with Winter 1.1, fixed issue with trailing data on imports','2025-08-02 11:05:52'),
(222,'Winter.Redirect','script','4.0.3','20220728_0014_add_forward_query_parameters.php','2025-08-02 11:05:52'),
(223,'Winter.Redirect','comment','4.0.3','Added support for forwarding query string params','2025-08-02 11:05:52'),
(224,'Winter.Redirect','comment','4.0.4','Match named regex groups to CMS Page parameters','2025-08-02 11:05:52'),
(225,'Winter.Redirect','comment','4.0.4','Add to_url to the list of available columns','2025-08-02 11:05:52'),
(226,'Winter.Redirect','comment','4.0.4','Fixed issue where Save & Close did not actually close','2025-08-02 11:05:52'),
(227,'Winter.Redirect','comment','4.0.4','Improved Russian translation','2025-08-02 11:05:52'),
(228,'Winter.Redirect','comment','4.0.4','Improved French translation','2025-08-02 11:05:52'),
(229,'Winter.Redirect','comment','4.0.4','Added Polish translation','2025-08-02 11:05:52'),
(230,'Winter.Redirect','comment','4.0.5','Improved Russian translation','2025-08-02 11:05:52'),
(231,'Winter.Redirect','comment','4.0.5','Fix clients relation conflict','2025-08-02 11:05:52'),
(232,'Winter.Redirect','comment','4.1.0','Switch to using new controller behavior default backend views added in Winter v1.2.8+','2025-08-02 11:05:52'),
(233,'Winter.Sitemap','comment','1.0.1','First version of Sitemap','2025-08-02 11:05:52'),
(234,'Winter.Sitemap','script','1.0.2','v1.0.2/create_definitions_table.php','2025-08-02 11:05:52'),
(235,'Winter.Sitemap','comment','1.0.2','Create definitions table','2025-08-02 11:05:52'),
(236,'Winter.Sitemap','comment','1.0.3','Minor improvements to the code.','2025-08-02 11:05:52'),
(237,'Winter.Sitemap','comment','1.0.4','Fixes issue where correct headers not being sent.','2025-08-02 11:05:52'),
(238,'Winter.Sitemap','comment','1.0.5','Minor back-end styling fix.','2025-08-02 11:05:52'),
(239,'Winter.Sitemap','comment','1.0.6','Minor fix to internal API.','2025-08-02 11:05:52'),
(240,'Winter.Sitemap','comment','1.0.7','Added access premissions.','2025-08-02 11:05:52'),
(241,'Winter.Sitemap','comment','1.0.8','Minor styling updates.','2025-08-02 11:05:52'),
(242,'Winter.Sitemap','comment','1.0.9','Replaced the 500 error with 404 when no definition is found. Added Czech translation. Improved Turkish, Hungarian and Portuguese (Brazil) translations.','2025-08-02 11:05:52'),
(243,'Winter.Sitemap','script','2.0.0','v2.0.0/rename_tables.php','2025-08-02 11:05:52'),
(244,'Winter.Sitemap','comment','2.0.0','Rebrand to Winter.sitemap','2025-08-02 11:05:52'),
(245,'Winter.Sitemap','script','2.0.1','v2.0.1/rename_indexes.php','2025-08-02 11:05:52'),
(246,'Winter.Sitemap','comment','2.0.1','Rebrand table indexes','2025-08-02 11:05:52'),
(247,'Winter.Sitemap','comment','2.0.2','Add composer replace config.','2025-08-02 11:05:52'),
(248,'Winter.Sitemap','comment','2.0.2','New events to allow extension.','2025-08-02 11:05:52'),
(249,'Winter.Sitemap','comment','2.0.2','Fire \'pages.menuItem.resolveItem\' as a halting event.','2025-08-02 11:05:52'),
(250,'Winter.Sitemap','comment','2.1.0','Fix saving sitemap definitions','2025-08-02 11:05:52'),
(251,'Winter.Sitemap','comment','2.1.0','Fix migrations on Laravel 9+','2025-08-02 11:05:52'),
(252,'Winter.Sitemap','comment','2.1.0','Invalid URLs are no longer added to the generated sitemap','2025-08-02 11:05:52'),
(253,'Winter.Sitemap','comment','2.1.0','Improve resolving the sitemap.xsl stylesheet','2025-08-02 11:05:52'),
(254,'Winter.Sitemap','comment','2.1.1','Fix saving sitemap definitions','2025-08-02 11:05:52'),
(255,'Winter.Sitemap','comment','2.2.0','Use new default backend views from Winter v1.2.8+','2025-08-02 11:05:52'),
(256,'NumenCode.SyncOps','comment','1.0.1','Initialize plugin','2025-08-02 11:10:36');
/*!40000 ALTER TABLE `system_plugin_history` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `system_plugin_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_plugin_versions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `version` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `is_disabled` tinyint(1) NOT NULL DEFAULT 0,
  `is_frozen` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `system_plugin_versions_code_index` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `system_plugin_versions` WRITE;
/*!40000 ALTER TABLE `system_plugin_versions` DISABLE KEYS */;
REPLACE INTO `system_plugin_versions` VALUES
(1,'Winter.Demo','1.0.1','2025-02-13 11:01:21',0,0),
(2,'Winter.Cloudflare','2.0.1','2025-02-18 15:34:07',0,0),
(3,'NumenCode.DropboxAdapter','1.0.1','2025-08-02 11:05:50',0,0),
(4,'NumenCode.Fundamentals','1.0.1','2025-08-02 11:05:50',0,0),
(5,'NumenCode.Widgets','1.0.9','2025-08-02 11:05:50',0,0),
(6,'Winter.Builder','2.1.1','2025-08-02 11:05:50',0,0),
(7,'Winter.Pages','2.2.0','2025-08-02 11:05:51',0,0),
(8,'Winter.Redirect','4.1.0','2025-08-02 11:05:52',0,0),
(9,'Winter.Sitemap','2.2.0','2025-08-02 11:05:52',0,0),
(10,'NumenCode.SyncOps','1.0.1','2025-08-02 11:10:36',0,0);
/*!40000 ALTER TABLE `system_plugin_versions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `system_request_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_request_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `winter_redirect_redirect_id` int(10) unsigned DEFAULT NULL,
  `status_code` int(11) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `referer` text DEFAULT NULL,
  `count` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `winter_redirect_request_log` (`winter_redirect_redirect_id`),
  CONSTRAINT `winter_redirect_request_log` FOREIGN KEY (`winter_redirect_redirect_id`) REFERENCES `winter_redirect_redirects` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `system_request_logs` WRITE;
/*!40000 ALTER TABLE `system_request_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_request_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `system_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_revisions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `field` varchar(255) DEFAULT NULL,
  `cast` varchar(255) DEFAULT NULL,
  `old_value` text DEFAULT NULL,
  `new_value` text DEFAULT NULL,
  `revisionable_type` varchar(255) NOT NULL,
  `revisionable_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_revisions_revisionable_id_revisionable_type_index` (`revisionable_id`,`revisionable_type`),
  KEY `system_revisions_user_id_index` (`user_id`),
  KEY `system_revisions_field_index` (`field`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `system_revisions` WRITE;
/*!40000 ALTER TABLE `system_revisions` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_revisions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(255) DEFAULT NULL,
  `value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_settings_item_index` (`item`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
REPLACE INTO `system_settings` VALUES
(1,'system_mail_settings','{\"send_mode\":\"smtp\",\"sender_name\":\"WebArea\",\"sender_email\":\"info@webarea.eu\",\"sendmail_path\":\"\\/usr\\/sbin\\/sendmail -t -i\",\"smtp_address\":\"smtp.eu.mailgun.org\",\"smtp_port\":587,\"smtp_user\":\"postmaster@ignoris.band\",\"smtp_password\":\"0d5fc7bc6ff9d237ab8be0f41ed4c707-ac3d5f74-c549d610\",\"smtp_authorization\":\"1\"}'),
(2,'winter_redirect_settings','{\"logging_enabled\":\"1\",\"statistics_enabled\":\"1\",\"test_lab_enabled\":\"1\"}');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `winter_redirect_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `winter_redirect_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `winter_redirect_categories` WRITE;
/*!40000 ALTER TABLE `winter_redirect_categories` DISABLE KEYS */;
REPLACE INTO `winter_redirect_categories` VALUES
(1,'General','2025-08-02 11:05:51','2025-08-02 11:05:51');
/*!40000 ALTER TABLE `winter_redirect_categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `winter_redirect_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `winter_redirect_clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `redirect_id` int(10) unsigned NOT NULL,
  `timestamp` timestamp NULL DEFAULT NULL,
  `day` tinyint(3) unsigned NOT NULL,
  `month` tinyint(3) unsigned NOT NULL,
  `year` smallint(5) unsigned NOT NULL,
  `crawler` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `redirect_dmy` (`redirect_id`,`day`,`month`,`year`),
  KEY `redirect_my` (`redirect_id`,`month`,`year`),
  KEY `redirect_timestamp_crawler` (`redirect_id`,`timestamp`,`crawler`),
  KEY `month_year_crawler` (`month`,`year`,`crawler`),
  KEY `month_year` (`month`,`year`),
  KEY `timestamp_crawler` (`timestamp`,`crawler`),
  CONSTRAINT `vdlp_redirect_client` FOREIGN KEY (`redirect_id`) REFERENCES `winter_redirect_redirects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `winter_redirect_clients` WRITE;
/*!40000 ALTER TABLE `winter_redirect_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `winter_redirect_clients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `winter_redirect_redirect_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `winter_redirect_redirect_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `redirect_id` int(10) unsigned NOT NULL,
  `from_to_hash` varchar(40) NOT NULL,
  `status_code` varchar(3) NOT NULL,
  `from_url` mediumtext NOT NULL,
  `to_url` mediumtext NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `redirect_log_unique` (`redirect_id`,`from_to_hash`,`status_code`),
  CONSTRAINT `vdlp_redirect_log` FOREIGN KEY (`redirect_id`) REFERENCES `winter_redirect_redirects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `winter_redirect_redirect_logs` WRITE;
/*!40000 ALTER TABLE `winter_redirect_redirect_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `winter_redirect_redirect_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `winter_redirect_redirects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `winter_redirect_redirects` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned DEFAULT NULL,
  `match_type` varchar(12) DEFAULT NULL,
  `target_type` varchar(12) NOT NULL DEFAULT 'path_or_url',
  `from_scheme` varchar(5) NOT NULL DEFAULT 'auto',
  `from_url` mediumtext DEFAULT NULL,
  `to_scheme` varchar(5) NOT NULL DEFAULT 'auto',
  `to_url` mediumtext DEFAULT NULL,
  `test_url` mediumtext DEFAULT NULL,
  `cms_page` varchar(255) DEFAULT NULL,
  `static_page` varchar(255) DEFAULT NULL,
  `requirements` text DEFAULT NULL,
  `status_code` varchar(3) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT 0,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `ignore_query_parameters` tinyint(1) NOT NULL DEFAULT 0,
  `ignore_case` tinyint(1) NOT NULL DEFAULT 0,
  `ignore_trailing_slash` tinyint(1) NOT NULL DEFAULT 0,
  `forward_query_parameters` tinyint(1) NOT NULL DEFAULT 0,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `test_lab` tinyint(1) NOT NULL DEFAULT 0,
  `test_lab_path` mediumtext DEFAULT NULL,
  `system` tinyint(1) NOT NULL DEFAULT 0,
  `description` varchar(255) DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `vdlp_redirect_redirects_sort_order_index` (`sort_order`),
  KEY `vdlp_redirect_redirects_is_enabled_index` (`is_enabled`),
  KEY `vdlp_redirect_redirects_category_id_foreign` (`category_id`),
  CONSTRAINT `vdlp_redirect_redirects_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `winter_redirect_categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `winter_redirect_redirects` WRITE;
/*!40000 ALTER TABLE `winter_redirect_redirects` DISABLE KEYS */;
/*!40000 ALTER TABLE `winter_redirect_redirects` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `winter_sitemap_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `winter_sitemap_definitions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `theme` varchar(255) DEFAULT NULL,
  `data` mediumtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `winter_sitemap_definitions_theme_index` (`theme`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `winter_sitemap_definitions` WRITE;
/*!40000 ALTER TABLE `winter_sitemap_definitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `winter_sitemap_definitions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

